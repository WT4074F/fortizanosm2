#!/usr/bin/env bash
# Run INSIDE a booted FortizanOS system (live session or installed) as a
# normal user. Automates the Milestone 1 acceptance checks and writes a log.
# Read-only except for one 'flatpak remote-ls' network call.
#
#   curl -O <raw url>/tests/verify-system.sh && bash verify-system.sh
set -uo pipefail

LOG="$HOME/fortizanos-verify-$(date +%Y%m%d-%H%M%S).log"
exec > >(tee "$LOG") 2>&1
PASS=0; FAIL=0; WARN=0
pass() { echo "  [PASS] $*"; PASS=$((PASS+1)); }
fail() { echo "  [FAIL] $*"; FAIL=$((FAIL+1)); }
warn() { echo "  [WARN] $*"; WARN=$((WARN+1)); }
check() { local d=$1; shift; if "$@" >/dev/null 2>&1; then pass "$d"; else fail "$d"; fi; }

LIVE=0; grep -q 'rd.live.image' /proc/cmdline && LIVE=1
echo "== FortizanOS M1 verification — $([ $LIVE = 1 ] && echo LIVE || echo INSTALLED) — $(date)"

echo "-- Identity"
# shellcheck disable=SC1091
. /etc/os-release
echo "  $PRETTY_NAME"
[ "$NAME" = FortizanOS ] && pass "os-release NAME=FortizanOS" || fail "os-release NAME is '$NAME'"
[ -f /usr/lib/fortizanos/build-info ] && pass "build-info present ($(grep GIT_COMMIT /usr/lib/fortizanos/build-info))" || fail "build-info missing"
[ -s /usr/lib/fortizanos/package-manifest.txt ] && pass "package manifest present" || fail "package manifest missing"

echo "-- KDE Plasma"
check "plasmashell running" pgrep -x plasmashell
if pgrep -x kwin_wayland >/dev/null; then pass "kwin_wayland running"
elif pgrep -x kwin_x11 >/dev/null; then pass "kwin_x11 running"
else fail "no KWin compositor running"; fi
echo "  session type: ${XDG_SESSION_TYPE:-unknown}, desktop: ${XDG_CURRENT_DESKTOP:-unknown}"
[ "${XDG_CURRENT_DESKTOP:-}" = KDE ] && pass "XDG_CURRENT_DESKTOP=KDE" || warn "XDG_CURRENT_DESKTOP='${XDG_CURRENT_DESKTOP:-}' (run from a Konsole inside Plasma)"
command -v plasmashell >/dev/null && echo "  $(plasmashell --version 2>/dev/null)"

echo "-- Networking"
check "NetworkManager active" systemctl is-active --quiet NetworkManager
[ "$(nmcli -t -f STATE general 2>/dev/null)" = connected ] && pass "nmcli: connected" || fail "nmcli state: $(nmcli -t -f STATE general 2>/dev/null)"
check "DNS resolves fedoraproject.org" getent hosts fedoraproject.org
check "HTTPS to mirrors.fedoraproject.org" curl -fsS -m 20 -o /dev/null https://mirrors.fedoraproject.org/
check "firewalld active" systemctl is-active --quiet firewalld

echo "-- Package management"
repos=$(dnf -q repolist --enabled 2>/dev/null | awk 'NR>1{print $1}')
grep -qx fedora  <<<"$repos" && pass "repo 'fedora' enabled"  || fail "repo 'fedora' not enabled"
grep -qx updates <<<"$repos" && pass "repo 'updates' enabled" || fail "repo 'updates' not enabled"
cat /etc/yum.repos.d/fedora.repo /usr/share/dnf5/repos.d/fedora.repo 2>/dev/null | grep -Eq '^gpgcheck=(1|true|True)' && pass "gpgcheck=1 on fedora repo" || fail "gpgcheck not enabled"
grep -q 'FortizanOS package-management defaults' /etc/dnf/dnf.conf && pass "FortizanOS dnf.conf defaults" || fail "dnf.conf defaults missing"
dnf -q check-update >/dev/null 2>&1; rc=$?
{ [ $rc -eq 0 ] || [ $rc -eq 100 ]; } && pass "dnf metadata download works (check-update rc=$rc)" || fail "dnf check-update failed (rc=$rc)"
check "rpm database consistent" rpm -q bash

echo "-- Flatpak"
check "flatpak installed" command -v flatpak
flatpak remotes --system 2>/dev/null | grep -q '^flathub' && pass "flathub remote configured" || fail "flathub remote missing (systemctl status fortizanos-flathub)"
check "flathub reachable (remote-ls)" timeout 120 flatpak remote-ls --system flathub --app --columns=application
check "Discover Flatpak backend installed" rpm -q plasma-discover-flatpak

echo "-- Basic utilities"
for c in bash ls cp mv rm grep sed awk tar gzip unzip zip curl wget less nano vi man htop lsof lspci lsusb ip ss \
         systemctl journalctl sudo konsole dolphin firefox; do
    command -v "$c" >/dev/null && pass "$c" || fail "$c not found"
done
failed_units=$(systemctl --failed --no-legend --plain 2>/dev/null)
if [ -z "$failed_units" ]; then pass "systemd reports no failed units"
else fail "failed systemd units:"; sed 's/^/        /' <<<"$failed_units"; fi

echo "-- Fortizan Aero desktop (Milestone 2)"
KR=$(command -v kreadconfig6 || true)
if [ -n "$KR" ]; then
    lnf=$("$KR" --file kdeglobals --group KDE --key LookAndFeelPackage)
    [ "$lnf" = org.fortizanos.aero.desktop ] && pass "global theme: $lnf" || fail "global theme is '$lnf'"
    cs=$("$KR" --file kdeglobals --group General --key ColorScheme)
    [ "$cs" = FortizanAero ] && pass "colour scheme: $cs" || fail "colour scheme is '$cs'"
    pt=$("$KR" --file plasmarc --group Theme --key name)
    [ "$pt" = fortizan-aero ] && pass "Plasma style: $pt" || fail "Plasma style is '$pt'"
    deco=$("$KR" --file kwinrc --group org.kde.kdecoration2 --key theme)
    case "$deco" in
        __aurorae__svg__FortizanAero) pass "window decoration: Fortizan Aero" ;;
        Breeze) warn "window decoration: Breeze (performance mode is on — 'fortizan-effects on' to restore)" ;;
        *) fail "window decoration is '$deco'" ;;
    esac
    blur=$("$KR" --file kwinrc --group Plugins --key blurEnabled --default true)
    echo "  blur effect enabled in config: $blur"
    icons=$("$KR" --file kdeglobals --group Icons --key Theme)
    [ "$icons" = FortizanAero ] && pass "icon theme: $icons" || fail "icon theme is '$icons'"
else
    fail "kreadconfig6 not found"
fi
check "fortizan-effects tool present" command -v fortizan-effects
check "Aurorae decoration engine installed" rpm -q aurorae
check "LibreOffice Writer installed" rpm -q libreoffice-writer
for p in akonadi_control mysqld mariadbd kdeconnectd; do
    if pgrep -x "$p" >/dev/null; then fail "background service '$p' is running (should be removed)"
    else pass "no '$p' background service"; fi
done
echo "  idle RAM now: $(awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf "%d MiB used of %d MiB", (t-a)/1024, t/1024}' /proc/meminfo)"

echo "-- Font"
if [ -n "$KR" ]; then
    f=$("$KR" --file kdeglobals --group General --key font)
    [ "${f%%,*}" = Selawik ] && pass "default UI font: Selawik" || fail "default UI font is '${f%%,*}'"
fi
m=$(fc-match -f '%{family[0]}' Selawik)
[ "${m#Selawik}" != "$m" ] && pass "Selawik installed and rendering" || fail "Selawik not found (renders as '$m')"
m=$(fc-match -f '%{family[0]}' 'Segoe UI')
echo "  'Segoe UI' requests render with: $m"

echo "-- Keyboard"
kb=$(localectl status 2>/dev/null | awk -F': *' '/X11 Layout/{print $2}')
[ "$kb" = gb ] && pass "system keyboard layout: gb (UK)" || fail "system keyboard layout is '${kb:-unknown}' (expected gb)"
if [ -n "$KR" ]; then
    kl=$("$KR" --file kxkbrc --group Layout --key LayoutList)
    [ "${kl%%,*}" = gb ] && pass "KDE keyboard layout: $kl" || fail "KDE keyboard layout is '$kl'"
fi

echo "-- Only Fortizan Aero themes installed"
others=$(ls /usr/share/plasma/look-and-feel 2>/dev/null | grep -vxE 'org.fortizanos.aero.desktop|org.kde.breeze.desktop')
[ -z "$others" ] && pass "global themes: Fortizan Aero (+ Breeze, required fallback)" || fail "extra global themes: $others"
others=$(ls /usr/share/color-schemes 2>/dev/null | grep -vx FortizanAero.colors)
[ -z "$others" ] && pass "colour schemes: Fortizan Aero only" || fail "extra colour schemes: $others"
others=$(ls /usr/share/plasma/desktoptheme 2>/dev/null | grep -vxE 'fortizan-aero|default')
[ -z "$others" ] && pass "Plasma styles: Fortizan Aero (+ default, required fallback)" || fail "extra Plasma styles: $others"
others=$(ls /usr/share/wallpapers 2>/dev/null | grep -vx FortizanAero)
[ -z "$others" ] && pass "wallpapers: Fortizan Aero only" || fail "extra wallpapers: $others"

echo "-- Filesystem"
fstype=$(findmnt -n -o FSTYPE /)
if [ $LIVE = 1 ]; then
    echo "  live session: root is $fstype (overlay is expected; Btrfs applies to installs)"
    grep -q 'default_scheme = BTRFS' /etc/anaconda/conf.d/90-fortizanos-storage.conf && pass "installer defaults to Btrfs" || fail "installer Btrfs config missing"
else
    [ "$fstype" = btrfs ] && pass "root filesystem is Btrfs" || fail "root filesystem is $fstype (expected btrfs)"
    findmnt -n -o OPTIONS / | grep -q 'compress=zstd' && pass "zstd compression on /" || warn "zstd compression not active on /"
    findmnt -n -o FSTYPE /home | grep -q btrfs && pass "/home on Btrfs" || warn "/home not a separate Btrfs subvolume"
    sudo -n btrfs subvolume list / 2>/dev/null | sed 's/^/        /' || echo "  (run with sudo to list subvolumes)"
fi

echo
echo "RESULT: $PASS passed, $FAIL failed, $WARN warnings"
echo "Log saved to $LOG"
exit "$FAIL"
