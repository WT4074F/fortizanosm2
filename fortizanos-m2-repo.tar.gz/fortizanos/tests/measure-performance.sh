#!/usr/bin/env bash
# Measure FortizanOS resource use on a running desktop. Run INSIDE the VM or
# installed system, as the normal user, from a Konsole window:
#
#   bash measure-performance.sh 0.2.0            # label = build you are testing
#   bash measure-performance.sh 0.2.0 --effects  # also measure with effects OFF
#
# Writes a Markdown report to ~/fortizanos-perf-<label>-<time>.md.
# Read-only except: with --effects it temporarily runs `fortizan-effects off`
# and restores your previous setting afterwards.
set -uo pipefail

LABEL=${1:-unlabelled}
EFFECTS=0; [ "${2:-}" = --effects ] && EFFECTS=1
SAMPLE=${SAMPLE_SECONDS:-30}
SETTLE=${SETTLE_SECONDS:-120}
OUT="$HOME/fortizanos-perf-${LABEL}-$(date +%Y%m%d-%H%M).md"

mem_used_mib() { awk '/MemTotal/{t=$2} /MemAvailable/{a=$2} END{printf "%d", (t-a)/1024}' /proc/meminfo; }
mem_total_mib() { awk '/MemTotal/{printf "%d", $2/1024}' /proc/meminfo; }

cpu_busy_pct() {   # whole-system CPU busy % over $1 seconds
    read -r _ u n s i w x y z _ < /proc/stat; t1=$((u+n+s+i+w+x+y+z)); i1=$((i+w))
    sleep "$1"
    read -r _ u n s i w x y z _ < /proc/stat; t2=$((u+n+s+i+w+x+y+z)); i2=$((i+w))
    awk -v dt=$((t2-t1)) -v di=$((i2-i1)) 'BEGIN{ if (dt>0) printf "%.1f", 100*(dt-di)/dt; else print "n/a" }'
}

proc_ticks() { awk '{print $14+$15}' "/proc/$1/stat" 2>/dev/null || echo 0; }
proc_rss_mib() { awk '/VmRSS/{printf "%d", $2/1024}' "/proc/$1/status" 2>/dev/null || echo 0; }

proc_cpu_pct() {   # per-process CPU % over $2 seconds (of one core)
    local pid=$1 a b hz; hz=$(getconf CLK_TCK)
    a=$(proc_ticks "$pid"); sleep "$2"; b=$(proc_ticks "$pid")
    awk -v d=$((b-a)) -v s="$2" -v hz="$hz" 'BEGIN{printf "%.1f", 100*d/(hz*s)}'
}

snapshot() {   # $1 = title
    local kwin plasma
    kwin=$(pgrep -x kwin_wayland | head -n1)
    plasma=$(pgrep -x plasmashell | head -n1)
    echo "### $1"
    echo
    echo "| Metric | Value |"
    echo "|---|---|"
    echo "| Used RAM (total − available) | $(mem_used_mib) MiB of $(mem_total_mib) MiB |"
    echo "| System CPU busy, ${SAMPLE}s idle sample | $(cpu_busy_pct "$SAMPLE") % |"
    [ -n "$kwin" ] && echo "| KWin (compositor) RAM / CPU | $(proc_rss_mib "$kwin") MiB / $(proc_cpu_pct "$kwin" 10) % of one core |"
    [ -n "$plasma" ] && echo "| Plasma shell RAM / CPU | $(proc_rss_mib "$plasma") MiB / $(proc_cpu_pct "$plasma" 10) % of one core |"
    echo "| Processes (all / this user) | $(ps -e --no-headers | wc -l) / $(ps -u "$USER" --no-headers | wc -l) |"
    echo
}

{
    echo "# FortizanOS performance report — $LABEL"
    echo
    echo "- Date: $(date -Iseconds)"
    . /etc/os-release; echo "- System: $PRETTY_NAME (build ${FORTIZANOS_BUILD_ID:-unknown})"
    echo "- Kernel: $(uname -r); session: ${XDG_SESSION_TYPE:-?}; live: $(grep -q rd.live.image /proc/cmdline && echo yes || echo no)"
    echo "- CPU: $(nproc) × $(awk -F': ' '/model name/{print $2; exit}' /proc/cpuinfo)"
    echo "- Machine: $(systemd-detect-virt 2>/dev/null || echo unknown) — VM numbers are for comparison between builds, not absolute"
    renderer=$(dbus-send --session --print-reply --dest=org.kde.KWin /KWin org.kde.KWin.supportInformation 2>/dev/null \
               | grep -m1 -i 'OpenGL renderer string' | sed 's/.*string: *//I')
    echo "- GPU renderer (KWin): ${renderer:-unknown} — 'llvmpipe' means software rendering, so blur costs CPU"
    echo
} > "$OUT"

up=$(awk '{printf "%d", $1}' /proc/uptime)
if [ "$up" -lt "$SETTLE" ]; then
    echo "Waiting $((SETTLE - up))s for the desktop to settle after boot..."
    sleep $((SETTLE - up))
fi
echo "Measuring (keep the mouse and keyboard still for about a minute)..."

snapshot "Idle, effects as configured ($(fortizan-effects status 2>/dev/null | awk '/blur/{print "blur " $2}'))" >> "$OUT"

if [ "$EFFECTS" = 1 ] && command -v fortizan-effects >/dev/null; then
    prev=$(kreadconfig6 --file kwinrc --group Plugins --key blurEnabled --default true)
    fortizan-effects off >/dev/null; sleep 20
    snapshot "Idle, effects OFF (performance mode)" >> "$OUT"
    [ "$prev" = true ] && fortizan-effects on >/dev/null
fi

{
    echo "### Background services check"
    echo
    for p in akonadi_control mysqld mariadbd kdeconnectd baloo_file; do
        if pgrep -x "$p" >/dev/null; then echo "- ⚠️ \`$p\` is running"; else echo "- \`$p\` not running"; fi
    done
    echo
    echo "### Top 15 processes by memory"
    echo
    echo '```'
    ps -eo rss=,comm= --sort=-rss | head -n 15 | awk '{printf "%7.1f MiB  %s\n", $1/1024, $2}'
    echo '```'
    echo
    echo "### Responsiveness (fill in by hand)"
    echo
    echo "- Open app launcher: instant / slight delay / slow"
    echo "- Open Dolphin: ___ s   Open Firefox: ___ s   Open LibreOffice Writer: ___ s"
    echo "- Drag a window over the taskbar: smooth / some stutter / choppy"
} >> "$OUT"

echo "Report written to $OUT"
cat "$OUT"
