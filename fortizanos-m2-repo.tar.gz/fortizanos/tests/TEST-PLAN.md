# Milestone 1 Test Plan

`[A]` = checked automatically by `tests/verify-system.sh`. `[M]` = manual.

## T1 — Build
| ID | Check | Pass criterion |
|---|---|---|
| T1.1 | `make preflight` | `PREFLIGHT OK` |
| T1.2 | Build from a fresh clone | ISO + sha256 in `out/<id>/` |
| T1.3 | `make verify` | `ISO VERIFY OK` |
| T1.4 | Second clean build | Also passes T1.2–T1.3 (reliability) |

## T2 — Boot (VirtualBox, run for UEFI and BIOS)
| ID | Check | Pass criterion |
|---|---|---|
| T2.1 [M] | Boot menu | Shows "FortizanOS 0.1.0" entries |
| T2.2 [M] | "Test this media & start" | Media check passes |
| T2.3 [M] | Boot to desktop | Reaches Plasma as `liveuser` without login prompt, < 3 min |

## T3 — Live session
| ID | Check | Pass criterion |
|---|---|---|
| T3.1 [A] | Identity | `NAME=FortizanOS`, build-info + manifest present |
| T3.2 [A] | Plasma | `plasmashell` + KWin running, `XDG_CURRENT_DESKTOP=KDE` |
| T3.3 [M] | Plasma usable | Panel, app launcher, System Settings, Konsole, Dolphin open |
| T3.4 [A] | Networking | NM connected, DNS, HTTPS to Fedora mirrors, firewalld active |
| T3.5 [M] | Browser | Firefox loads a web page |
| T3.6 [A] | Package management | fedora + updates enabled, gpgcheck=1, `dnf check-update` works |
| T3.7 [A] | Flatpak | flathub remote configured and reachable |
| T3.8 [M] | Discover | Discover lists Flathub apps |
| T3.9 [A] | Utilities | Core CLI tools present, no failed systemd units |
| T3.10 [A] | Installer config | Anaconda Btrfs default present |

## T4 — Installation
| ID | Check | Pass criterion |
|---|---|---|
| T4.1 [M] | Launch installer | "Install to Hard Drive" opens Anaconda |
| T4.2 [M] | Automatic partitioning | Default scheme shown is **Btrfs** |
| T4.3 [M] | Install | Completes without error |
| T4.4 [M] | Reboot | Removes ISO, boots to login screen, user can log in to Plasma |
| T4.5 [A] | Filesystem | `/` is Btrfs with zstd compression, `/home` subvolume |
| T4.6 [A] | Everything in T3 | Re-run `verify-system.sh` on installed system |
| T4.7 [M] | Update | `sudo dnf upgrade` completes; system reboots cleanly |
| T4.8 [M] | Flatpak install | `flatpak install flathub org.kde.kcalc` installs and launches |

## T5 — Fortizan Aero desktop (Milestone 2)
| ID | Check | Pass criterion |
|---|---|---|
| T5.1 [A] | Theme active | `verify-system.sh` reports global theme, colour scheme, Plasma style, decoration, icons = Fortizan Aero |
| T5.2 [M] | Taskbar | Full-width bottom bar, dark blue frosted glass, logo launcher, task buttons with labels, tray, clock + date, show-desktop corner |
| T5.3 [M] | Window decorations | Active title bar blue glass with cyan top edge; inactive muted; min/max/close work; double-click title maximises; maximised title bar fills the top |
| T5.4 [M] | Glass + readability | Panel, pop-ups (launcher, tray, calendar), notifications and tooltips are blurred glass; all text readable on light *and* busy wallpapers |
| T5.5 [M] | Context menus | Right-click on desktop and in Dolphin: lightly frosted menu, readable |
| T5.6 [M] | Apps launch | Dolphin, Konsole, Firefox, LibreOffice Writer, Okular, Discover, System Settings open normally and use the blue/white colours |
| T5.7 [M] | Effects switch | Menu → "Visual Effects On/Off": blur, animations and glass title bars turn off (solid navy/Breeze); run again → restored. Desktop still looks finished when off |
| T5.8 [A] | No heavy services | `verify-system.sh`: no akonadi / mysqld / mariadbd / kdeconnectd |
| T5.9 [A] | Performance | `measure-performance.sh <build> --effects` report saved; idle RAM target < 1.5 GiB; compare with 0.1.0 |
| T5.11 [A] | Single theme | `verify-system.sh`: only Fortizan Aero global theme/style/colours/wallpaper (+ required Breeze/default fallbacks); System Settings shows no other choices |
| T5.12 [A] | UK keyboard | `verify-system.sh`: system and KDE layout = gb; typing `£`, `"`, `@` and `#` gives the UK characters |
| T5.13 [M] | Transparency | Drag a window over another window and over the wallpaper: its borders/title bar show the blurred content behind; title text stays readable |
| T5.14 [M] | Flat title bars | Title bars are one even transparent tint — no gradient, shine or glow; flat buttons (min/max show a flat tint only on hover; close is flat red) |
| T5.15 [A] | Font | `verify-system.sh`: default font Selawik, installed and rendering; menus, title bars and apps visibly use it |
| T5.10 [M] | Installed system | After install + reboot, the new user gets the same Fortizan Aero desktop |

## Results log
| Date | Build ID | Git commit | Firmware | T1 | T2 | T3 | T4 | Tester | Notes |
|---|---|---|---|---|---|---|---|---|---|
| | | | | | | | | | |
