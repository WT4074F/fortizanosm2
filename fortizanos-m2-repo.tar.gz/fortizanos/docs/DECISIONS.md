# Design decisions — Milestone 1

### D-001 Image tool: livemedia-creator (lorax), not KIWI
Fedora's own release ISOs have been built with KIWI (`fedora-kiwi-descriptions`)
since Fedora 42. We nonetheless use livemedia-creator for M1 because:
it is an official, packaged Fedora tool; it works directly from kickstarts,
which are short and readable; it produces an ISO with Anaconda wired up for
live installs; and community reports show "stock" KIWI builds of Fedora live
ISOs from the public descriptions can need extra, undocumented steps.
**Revisit in M2+** if we need parity with Fedora's compose pipeline.

### D-002 Base: stock Fedora 45 KDE Plasma
Package set followed Fedora KDE (`@^kde-desktop-environment`, `@kde-apps`,
`@kde-media`, `@firefox`). **Correction (M2):** the 0.1.0 build logs show this
environment *did* pull in LibreOffice, the KDE PIM suite (with Akonadi and a
MariaDB server) and many extra apps, contrary to what was stated earlier.
Milestone 2 trims this deliberately (D-009).
No desktop customisation in M1 (project rule).
**Owner decision (2026-11-16):** FortizanOS aims to be lightweight. LibreOffice
is the only office suite and is added in **M2**, not M1. No other office/PIM
suites. Firefox is the only browser (Falkon/Konqueror may be excluded).

### D-003 Branding: NAME changes, `ID=fedora` stays (for now)
`os-release` gets `NAME="FortizanOS"`, a FortizanOS `PRETTY_NAME`, and
`FORTIZANOS_*` fields. `ID` and `VARIANT_ID` stay Fedora's because Anaconda
selects its product profile (including the UEFI directory `EFI/fedora` that
shim/grub install to) from them. Changing `ID` without shipping our own
installer profile produces installs that do not boot on UEFI.
**M2 task:** a `fortizanos-release` RPM + Anaconda profile, then `ID=fortizanos`, `ID_LIKE=fedora`.

### D-004 Btrfs default via Anaconda `conf.d`
The live medium itself uses Fedora's standard read-only image + overlay; Btrfs
applies to **installed** systems. `/etc/anaconda/conf.d/90-fortizanos-storage.conf`
sets `default_scheme = BTRFS`, `zstd:1` compression and `/`, `/home`, `/var`
subvolumes. Anaconda loads `conf.d` after the profile, so this wins regardless
of upstream profile changes. Fedora KDE already defaults to Btrfs; we make it
explicit so it can't regress silently. Snapshots (snapper/btrfs-assistant) → M2.

### D-005 Flatpak: Flathub enabled system-wide
Added at build time when the builder has network, and by
`fortizanos-flathub.service` on first boot otherwise (retries until online,
runs once). Discover's Flatpak backend is installed. Note this enables the
unfiltered Flathub remote, unlike Fedora's default of the Fedora Flatpak
registry plus opt-in third-party repositories.

### D-006 Package management
- Official `fedora` + `updates` repos only, via metalinks (checksum-verified mirror selection), GPG checking on.
- `/etc/dnf/dnf.conf`: `max_parallel_downloads=10`, `installonly_limit=3`, `skip_if_unavailable=False`.
- No third-party RPM repos in M1 (e.g. RPM Fusion) — reduces breakage surface.
- Every image records exact package versions in `/usr/lib/fortizanos/package-manifest.txt`.
- **Not yet done:** pinned snapshot repos for bit-for-bit package reproducibility. Planned once the build is reliable.

### D-007 Safety rules in scripts
Builds never overwrite or delete earlier outputs (timestamped `out/<id>/`).
Scripts never change SELinux mode, never delete VMs or disks, and never
partition host disks; where such an action is needed they stop and print the
command for a human to run.

### D-008 Desktop identity is data, not code (M2)
Fortizan Aero is implemented entirely with standard KDE theme formats
(Plasma style, Aurorae decoration, colour scheme, icon theme, wallpaper,
global theme) plus `/etc/xdg` defaults. No new compositor, shell or daemon.
All assets are generated from `tools/palette.py` by `tools/gen-theme.py`.

### D-009 Lightweight package set (M2)
Removed Akonadi/MariaDB + PIM apps, KDE Connect, duplicates and niche apps;
kept one app per job and LibreOffice Writer/Calc/Impress. See PACKAGES.md.
`make preflight` resolves the full transaction to catch broken removals.

### D-010 Aurorae v1 for title bars (M2)
Breeze cannot draw translucent title bars (KDE declined to add it), so glass
title bars need Aurorae. We pin `library=org.kde.kwin.aurorae` (the
documented SVG engine). Cost: slightly more RAM than Breeze; the effects
switch returns to Breeze.

### D-011 Defaults live in /etc/xdg, colours included (M2)
`/etc/xdg/kdeglobals` names the global theme *and* carries the full colour
groups, because some apps read colours from kdeglobals directly. Users'
own `~/.config` settings always win. Originals are backed up as
`*.fortizanos-orig`.

### D-012 Cheaper defaults (M2)
No login splash (`Engine=none`), file search indexes names only, animations
at KDE's "slightly faster" step (0.7071). All reversible in System Settings.

### D-013 Longhorn 4074 transparent glass (M2, owner feedback)
v0.2.0's dark navy glass did not match 4074. Redesigned to 4074's defining
traits: clear pale window borders (vs. "Jade"'s greenish ones), transparent
smoked taskbar, clear glass caption buttons with red close, dark title text
with white halo. The start button uses the FortizanOS orb + "Start" label —
never the Windows logo. Strong KWin blur (10) keeps text readable.

### D-014 Single theme (M2, owner request)
All non-Fortizan themes removed in `theme-cleanup.ks`; `%_netsharedpath`
keeps them out on updates. Kept as hidden-in-practice fallbacks because
Plasma requires them: Breeze global theme (lock/logout/OSD), "default"
Plasma style, Breeze decoration (performance mode), Breeze/hicolor/Adwaita
icons. GTK theme (breeze-gtk) kept so GTK apps are styled.

### D-015 UK keyboard default (M2, owner request)
`keyboard --vckeymap=gb --xlayouts=gb` plus `/etc/xdg/kxkbrc`
(`LayoutList=gb`) for the Wayland session. Language stays English (US) and
time zone UTC unless the owner decides otherwise.

### D-016 Flat transparent title bars (M2, owner direction)
Title bars and window borders are a single even transparent tint (no
gradient, reflection or glow) with a 1px hairline; caption buttons are flat
(no background until hover; close is flat red). Title text keeps a soft
white halo for readability on transparent glass. Taskbar/pop-ups unchanged.

### D-017 Selawik as the default font (M2, owner direction)
All UI fonts (kdeglobals) are **Selawik** — Microsoft's open-source,
metric-compatible replacement for Segoe UI (SIL OFL 1.1). Selawik is not in
Fedora's repositories, so `scripts/fetch-fonts.sh` downloads Microsoft's
official 1.01 release at build time and refuses it unless its SHA-256
matches the pinned value (cross-checked with Homebrew's `font-selawik`
cask). The OFL licence is installed alongside. `59-fortizanos-segoe-ui.conf`
also maps "Segoe UI" requests (documents, websites) to Selawik. Segoe UI
itself is never shipped.

### Open issue — trademarks (before public release)
The image still contains Fedora logos and artwork (`fedora-logos`). Fine for
internal testing, but Fedora's trademark guidelines require remixes that are
distributed publicly to remove Fedora marks (typically by swapping in
`generic-logos`/our own logo package). **Must be resolved before any public ISO.**
