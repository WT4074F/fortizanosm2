# Building the FortizanOS ISO

## Toolchain

FortizanOS uses **livemedia-creator** from Fedora's **lorax** package — the
Fedora-maintained tool that turns a kickstart into a bootable live ISO with
the Anaconda installer. See `docs/DECISIONS.md` D-001 for why this rather
than KIWI (which Fedora release engineering uses for its own composes).

The image is defined entirely by kickstart files plus `overlay/`. The build
flattens them into one self-contained file (`build/fortizanos-flat.ks`),
which is saved next to every ISO so any build can be inspected or repeated.

## Requirements

| Resource | Minimum | Recommended |
|---|---|---|
| OS | Fedora 45 (host build) **or** any Linux with podman/docker (container build) | Fedora 45 |
| CPU | 2 cores | 4+ cores |
| RAM | 8 GiB | 16 GiB |
| Free disk | 30 GiB in `/var/tmp` (or `WORK_DIR`) | 50 GiB |
| Network | HTTPS to `mirrors.fedoraproject.org`, Fedora mirrors, `dl.flathub.org` | wired, unmetered (~3 GiB per build) |
| Privileges | root (loop devices, chroot) | — |

Run `make inspect` to check a machine against this list.

## Option A — Fedora 45 host

```bash
git clone <repo> fortizanos && cd fortizanos
make inspect
make setup                # installs lorax, lorax-lmc-novirt, pykickstart, xorriso…
make preflight            # catches missing packages/groups in ~1 minute
```

SELinux must be **Permissive during the build** (a known requirement of
`livemedia-creator --no-virt`). The scripts will not change this for you:

```bash
sudo setenforce 0         # temporary; reverts on reboot
sudo make iso
sudo setenforce 1         # restore immediately afterwards
```

## Option B — container (any Linux host)

```bash
make iso-container        # uses podman, or docker if podman is absent
```

Runs the official `registry.fedoraproject.org/fedora:45` image with
`--privileged` and `/dev` mounted (needed for loop devices). On an SELinux
host, the same Permissive note as Option A applies.

## Option C — GitHub Actions

Push the repo to GitHub and run **Actions → Build ISO → Run workflow**. The
ISO, checksum, flattened kickstart and logs are uploaded as artifacts
(kept 14 days). A newer commit automatically cancels an older running build.

**Updating the repository without git (website upload):** upload an archive
named `fortizanos-<anything>-repo.tar.gz` with **Add file → Upload files**.
The workflow's first job unpacks it over the repository, commits the files
and removes the archive, then builds. The archive never changes
`.github/workflows/` — edit that file on the website when it needs updating.

## Outputs

```
out/<BUILD_ID>/
  FortizanOS-0.1.0-F45-KDE-x86_64.iso
  FortizanOS-0.1.0-F45-KDE-x86_64.iso.sha256
  fortizanos-flat.ks        exact build input
  build-info.txt            git commit, lorax/anaconda versions, duration
  logs/                     livemedia-creator + anaconda logs
```

Every build gets a new `BUILD_ID` directory (UTC timestamp by default), so
earlier ISOs are never overwritten. Delete old ones yourself when no longer
needed. `make clean` only removes generated files in `build/`.

Inside the image, `/usr/lib/fortizanos/package-manifest.txt` records the
exact version of every RPM.

## Reproducibility

Same git commit + same `build.conf` ⇒ same package *set* and configuration.
Package *versions* follow Fedora's `updates` repo, so two builds a week apart
will contain newer updates — the package manifest records exactly which. Full
version pinning (local snapshot repo) is planned once the build is stable;
see DECISIONS D-006.

## Changing things

| To change… | Edit |
|---|---|
| Fedora release, ISO name/label | `build.conf` |
| Packages | `kickstarts/include/kde.ks` (desktop/utilities) or `live-base.ks` (boot/installer) |
| Distro configuration | `kickstarts/include/fortizanos.ks` |
| Files shipped in the image | add them under `overlay/` with the target path |

Always run `make preflight` after editing package lists.

## Troubleshooting

| Symptom | Cause / fix |
|---|---|
| `SELinux is Enforcing` | See Option A. |
| `host is Fedora NN, build.conf wants 45` | `--no-virt` uses the host's Anaconda; use `make iso-container`. |
| `PREFLIGHT FAILED: MISSING package: X` | Package renamed/retired in this Fedora release. Remove or rename it in the kickstart. |
| Build stops in `%post` with `ERROR:` | A FortizanOS self-check failed; the message names it. Full log: `out/<id>-logs/logs/`. |
| `No space left on device` | Point `WORK_DIR=/bigdisk/tmp` (host) or `WORK_HOST=` (container) at a larger disk. |
| `failed to set up loop device` (container) | Container needs `--privileged` and `-v /dev:/dev` (the script does this); rootless podman will not work — run with sudo. |
| ISO boots but `verify-iso` reports missing `/images/pxeboot/vmlinuz` | Lorax template layout changed; check `xorriso -indev ISO -find /` and update `verify-iso.sh`. |
