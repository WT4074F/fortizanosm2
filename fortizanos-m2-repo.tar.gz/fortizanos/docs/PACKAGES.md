# FortizanOS package set (Milestone 2)

The exact list of every RPM in a build is generated automatically and shipped
inside the image at `/usr/lib/fortizanos/package-manifest.txt` (and the build
log). This page explains the *choices*.

## Principle

One application per job. No permanent background services for features most
people don't use. Anything removed here can be installed from **Discover**
in a couple of clicks.

## Base

| Source | What it brings |
|---|---|
| `@^kde-desktop-environment` | Fedora's KDE Plasma 6.8 desktop (Wayland) |
| `@firefox` | Web browser |
| `fedora-release-kde-desktop` | Fedora 45 KDE system identity (rebranded in `%post`) |
| live/installer packages | see `kickstarts/include/live-base.ks` |

## Bundled outside Fedora's repositories

| Item | Source | Verification |
|---|---|---|
| Selawik font 1.01 (default UI font, SIL OFL 1.1) | github.com/microsoft/Selawik release | SHA-256 pinned in `scripts/fetch-fonts.sh` |

## Kept applications (one per job)

| Job | App |
|---|---|
| Files | Dolphin |
| Terminal | Konsole |
| Text editor | KWrite |
| Office | LibreOffice Writer, Calc, Impress |
| Web | Firefox |
| PDF / documents | Okular |
| Images | Gwenview |
| Simple painting | KolourPaint |
| Screenshots | Spectacle |
| Music | Elisa |
| Video | Dragon Player |
| Archives | Ark |
| Calculator | KCalc |
| Software | Discover (+ Flathub) |
| System info / monitor | Info Centre, System Monitor |
| Disks | KDE Partition Manager, Filelight |
| Passwords | KWallet Manager |
| First-run tour | Plasma Welcome |

## Removed in Milestone 2 (present in 0.1.0)

| Removed | Why |
|---|---|
| Akonadi server **+ MariaDB server**, KDE PIM runtime/add-ons | Background database server per user — largest idle RAM/CPU cost |
| KMail, Kontact, KOrganizer, KAddressBook, Akregator, import/export/sieve tools, Kleopatra | Depend on Akonadi; owner decision: no PIM suite |
| KDE Connect (+ daemon) | Permanent background daemon |
| Krusader, KFind, digiKam | Duplicate Dolphin / Dolphin search / Gwenview |
| K3b, KTorrent, NeoChat, Qrca, KMouth, KRDC, KRFB, Kamoso, Skanpage | Niche; large dependency trees |
| KDebugSettings, KJournald | Developer tools |
| KMahjongg, KPatience, KMines | Games (installable) |

Exclusions are written as `-package` lines in `kickstarts/include/kde.ks`.
`make preflight` resolves the whole set before every build, so if a removal
is still needed by something else the problem shows up in about a minute.

## Measuring the effect

Package count and size are printed by `make preflight`. Runtime effect (RAM,
CPU, processes) is measured with `tests/measure-performance.sh` — see
`docs/PERFORMANCE.md`.
