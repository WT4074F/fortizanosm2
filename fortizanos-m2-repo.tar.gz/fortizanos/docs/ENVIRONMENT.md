# Build environment

Run `make inspect` on any candidate build machine; it checks everything below
and exits non-zero on blocking problems.

## Inspection log

### 2026-11-15 — initial setup workspace (Claude cloud sandbox)

| Item | Found | Verdict |
|---|---|---|
| OS | Ubuntu 24.04.5 LTS | Not Fedora — container build only |
| CPU | 2 × Intel Xeon @ 2.10 GHz | Below recommended 4 |
| RAM | 7.8 GiB, no swap | Borderline (8 GiB minimum) |
| Storage | 31 GiB free | Just meets 30 GiB minimum |
| KVM | `/dev/kvm` absent | No VM boot testing possible |
| Containers | docker client only, no usable registry access | Container build not possible |
| Network | Fedora mirrors and registries blocked (HTTP 403 / no route) | **Blocking** — cannot download RPMs |
| Tools | git present; lorax, pykickstart, xorriso absent | — |

**Outcome:** this workspace was used to author the repository, documentation
and static checks only. The ISO must be built on a Fedora 45 machine, a
Linux host with podman/docker and internet access, or GitHub Actions.

### Next machine
Append a section here with the `make inspect` output from the first real build host.
