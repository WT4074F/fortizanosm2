# Performance — measurements and design choices

## Status

**No measurements yet.** The build workspace cannot run a desktop, so all
figures must come from `tests/measure-performance.sh` run inside the VM (or
on real hardware). This file holds the results; fill in the table as each
build is tested. Nothing below is an assumed number.

## How to measure

1. Boot the ISO (live session) and log in; do not open any apps.
2. Open Konsole, run: `bash measure-performance.sh <build-label> --effects`
3. Keep still for ~1 minute. The report is saved in your home folder.
4. Copy the key numbers into the table below (and keep the report file).

Do the same with the **0.1.0** ISO to get the "before" figures — same VM,
same settings.

## Results

| Build | Machine | Idle RAM | Idle CPU | KWin CPU (effects on) | KWin CPU (effects off) | Processes | Notes |
|---|---|---|---|---|---|---|---|
| 0.1.0 (M1 baseline) | VirtualBox 4 GiB / 2 CPU | | | | | | |
| 0.2.0 (M2) | VirtualBox 4 GiB / 2 CPU | | | | | | |

Target: idle RAM **below 1.5 GiB**.

## What M2 changes, and the expected direction

| Change | Expected effect | Why |
|---|---|---|
| Removed Akonadi + MariaDB server, KDE PIM | **Lower** RAM and CPU after login | These start a database server for each user |
| Removed KDE Connect daemon | Lower RAM, fewer processes | Permanent background service |
| File search indexes names only | Much lower CPU/disk after first login | Content indexing reads every file |
| No splash screen | Faster login | Splash is purely cosmetic |
| Animations 30 % shorter | Feels snappier | Same effects, less time |
| Blur + contrast effects (glass) | **Slightly higher** GPU/CPU while windows move | Blur is computed per frame behind glass surfaces |
| Aurorae title bars | Slightly higher RAM than Breeze | Aurorae draws from SVG/QML |

The last two are the price of the glass look. `fortizan-effects off` removes
both (and animations), so users on weak hardware can trade looks for speed
in one click. Blur runs on the GPU on real hardware; in a VM without 3D it
falls back to the CPU, which exaggerates its cost.

## Tuning knobs (if measurements disappoint)

| Knob | File | Lighter setting |
|---|---|---|
| Blur strength | `tools/palette.py` `BLUR_STRENGTH` | 4–5 (cheaper, less frosted) |
| Context-menu blur | `MENU_OPACITY_PERCENT` | 100 (solid, no blur) |
| Window title blur | remove `mask` frame in `gen-theme.py` | title bars translucent but not blurred |
| Animations | `ANIM_FACTOR` | `0` |
