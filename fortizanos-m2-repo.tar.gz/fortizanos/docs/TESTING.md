# Testing FortizanOS

Testing has three layers. A build is only "good" when all three pass.

1. **Static checks before/after building**
   - `python3 tools/check-theme.py` — every theme graphic is well-formed and
     renders at its exact intended size (runs in seconds, no build needed).
   - `make preflight` — every package exists and the whole set resolves.
   - `make verify` (automatic at the end of every build) — ISO structure,
     BIOS + UEFI boot entries, checksums.
2. **Live session in VirtualBox** — `make vbox-test`, then inside the VM run
   `tests/verify-system.sh` and `tests/measure-performance.sh`.
3. **Installed system** — install from the live session to the VM disk,
   reboot, run both scripts again (now also checks Btrfs).

The full checklist with pass criteria is in [`tests/TEST-PLAN.md`](../tests/TEST-PLAN.md).
Record results in the table at the bottom of that file.

## VirtualBox settings (important)

Lessons from the first boot tests of 0.1.0:

| Setting | Value | Why |
|---|---|---|
| Type / Version | Linux / **Fedora (64-bit)** | A 32-bit type gives the VM an i686 CPU and the kernel refuses to boot |
| Base memory | **4096 MB** or more | Plasma + installer |
| Processors | **2** or more | |
| Graphics controller | **VMSVGA** | |
| Video memory | **128 MB** (maximum) | With 16 MB the screen fails to change resolution ("cannot allocate memory, modeset failed") and loops |
| 3D acceleration | **On** | Plasma 6.8 is Wayland-only; without 3D the desktop can stay black in VirtualBox 7.2 |
| EFI | On (also test once with it off = BIOS) | |

On the Windows host, VirtualBox is slow or unstable if **Hyper-V** is active
(green turtle icon in the VM status bar): turn off *Memory integrity* and the
Hyper-V / Virtual Machine Platform / Windows Hypervisor Platform features,
then restart Windows.

`make vbox-test` (on a Linux/macOS host with VBoxManage) creates a VM with
these settings. It refuses to touch an existing VM of the same name.
Removing a test VM (`VBoxManage unregistervm NAME --delete`) destroys its
disk — do it deliberately.

## Getting the test scripts into the VM

In the live session open Konsole and download them from your GitHub
repository's "raw" view, for example:

```
curl -LO https://raw.githubusercontent.com/<user>/<repo>/main/tests/verify-system.sh
curl -LO https://raw.githubusercontent.com/<user>/<repo>/main/tests/measure-performance.sh
bash verify-system.sh
bash measure-performance.sh 0.2.0 --effects
```

(Private repositories need a browser download instead.)

## Performance numbers in a VM

VirtualBox's 3D support is limited; KWin may fall back to software rendering
("llvmpipe" in the report), which makes blur cost CPU. Use VM numbers to
**compare builds with each other**, not as absolute figures for real
hardware. See `docs/PERFORMANCE.md`.

## Milestone exit criteria

**Milestone 1** — two consecutive clean builds; live session passes
`verify-system.sh` on UEFI and BIOS; installation to a blank disk boots to
Plasma with root on Btrfs.

**Milestone 2** — all of T5 in the test plan; performance report for the
M2 build and the 0.1.0 baseline recorded in `docs/PERFORMANCE.md`.
