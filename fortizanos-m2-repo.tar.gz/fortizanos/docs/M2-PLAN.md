# Milestone 2 — Implementation plan: desktop foundation & visual identity

Status: plan agreed by implementation; see PROJECT_STATUS.md for progress.

## 1. What we are building on (inspected, not assumed)

From the Milestone 1 build logs (run that produced 0.1.0, 2026-11-16):

| Component | Version in image |
|---|---|
| Fedora | 45 |
| KDE Plasma (plasma-workspace, plasma-desktop, KWin) | 6.8.1 |
| KDE Frameworks | 6.31 |
| Qt | 6.11 |
| Window decoration engines | Breeze 6.8.1, **Aurorae 6.8.1** (SVG themes) |
| Login screen | plasma-login-manager (replaces SDDM in Plasma 6.8) |
| Session type | Wayland only (no Plasma X11 session installed) |
| Packages in image | 2,318 |

## 2. Approach in one sentence

We **customise KDE with themes and configuration files** — no new desktop
shell, no new compositor, no background services. Everything is data
(colours, SVG graphics, config) that KDE already knows how to load.

### What each piece is (beginner's guide)

| Piece | What it controls | Where it lives in the image |
|---|---|---|
| **Colour scheme** | Colours of every app (windows, buttons, menus, selections) | `/usr/share/color-schemes/FortizanAero.colors` |
| **Plasma style** ("desktop theme") | The taskbar, pop-ups, notifications, tooltips — drawn from SVG pictures | `/usr/share/plasma/desktoptheme/fortizan-aero/` |
| **Window decoration** (Aurorae theme) | Title bars, borders, min/max/close buttons | `/usr/share/aurorae/themes/FortizanAero/` |
| **Icon theme** | Branded icons; everything else inherited from Breeze | `/usr/share/icons/FortizanAero/` |
| **Wallpaper** | Desktop background | `/usr/share/wallpapers/FortizanAero/` |
| **Global theme** ("look-and-feel") | Bundles all of the above + the taskbar layout | `/usr/share/plasma/look-and-feel/org.fortizanos.aero.desktop/` |
| **System defaults** | Makes the above the default for every new user | `/etc/xdg/*` |
| **Effects switch** | One command / menu item to turn glass + animations off/on | `/usr/bin/fortizan-effects` |

Because these are standard KDE theme formats, users can still change
any of them in System Settings, and each can be swapped independently.

## 3. Glass design → KDE mechanism

KWin (KDE's compositor) already has a **Blur** effect (true background blur,
GPU-accelerated) and a **Background contrast** effect. Plasma styles can ship
two variants of every graphic: *translucent* (used when blur is on) and
*opaque* (used when it is off). We use exactly that — no extra software.

| Element | Treatment | Implemented by |
|---|---|---|
| Taskbar | Dark blue frosted glass | Plasma style `translucent/widgets/panel-background` (~72 % opaque navy) + KWin blur + contrast |
| Pop-ups, notifications, tooltips | Frosted glass, slightly lighter navy | Plasma style `translucent/dialogs/background`, `widgets/tooltip` |
| Context menus (in apps) | Lightly frosted | Breeze widget style `MenuOpacity=88` + blur |
| Window borders/title bars | Semi-transparent glass | Aurorae SVG theme (translucent frame) |
| Active window | Subtle luminous blue highlight | Aurorae active frame: cyan top highlight + accent line |
| Inactive window | Muted frosted | Aurorae inactive frame: desaturated, lower contrast |
| App content (text areas, lists) | **Solid** — never transparent | Colour scheme (readability rule) |

Approximate 70/30 balance: blur strength is set so glass surfaces read as
*frosted* (blurred, tinted) rather than see-through; only the window frame
is plainly translucent.

## 4. Lightweight changes

M1 used Fedora KDE's full default app set. The logs show it pulled in
duplicates and background services. M2 removes:

- **Akonadi + KMail/Kontact/KOrganizer/KAddressBook** — Akonadi runs a database
  server in the background; largest single idle-RAM saving.
- **KDE Connect** — permanent background daemon.
- Duplicates: Krusader (Dolphin), KFind (Dolphin search), digiKam (Gwenview),
  Kate-style extras, Kamoso (webcam).
- Niche/large: K3b, KTorrent, NeoChat, Qrca, KRDC, KRFB, KMouth, Skanpage,
  KDebugSettings, KJournald, games (KMahjongg, KPat, KMines).

Kept (one app per job): Dolphin, Konsole, KWrite, Ark, Okular, Gwenview,
Spectacle, KCalc, Elisa, Dragon Player, Firefox, Discover, System Monitor,
Info Centre, Partition Manager, Filelight, **LibreOffice Writer/Calc/Impress**
(owner decision), Plasma Welcome.

Safety net: `make preflight` now performs a full **dependency resolution**
of the package set (≈1 min) so a removal that breaks something is caught
before the hour-long build.

## 5. Measurement plan

`tests/measure-performance.sh` (run inside the VM / installed system) records
idle RAM, CPU after startup, process list, KWin cost, and repeats with
effects off — producing a before/after table. Targets: idle RAM < 1.5 GB.
M1 baseline must be measured on the 0.1.0 ISO for a true before/after.

## 6. Out of scope (Milestone 3+)

Start menu, Run dialog, Explorer replacement, Wine, desktop sidebar,
login-screen theme, boot splash artwork. The stock application launcher
stays (themed only) so the desktop remains usable.

## 7. Risks and how they are handled

| Risk | Mitigation |
|---|---|
| Visuals cannot be seen until an ISO boots (no Plasma in the build workspace) | Every SVG is rendered to PNG previews during development; KDE format rules followed exactly; theme falls back to Breeze for any graphic we do not ship |
| Aurorae decorations cost slightly more than Breeze | Effects switch also swaps to Breeze decoration in "performance mode" |
| Package removals break dependencies | Dependency preflight |
| VirtualBox black screen seen in M1 testing | Test with VMSVGA + 3D acceleration on; documented in TESTING.md. Still an **open M1 item** |
| M1 exit criteria (2 clean builds, install test) not fully met | Tracked in PROJECT_STATUS.md; M2 build doubles as the second build |
