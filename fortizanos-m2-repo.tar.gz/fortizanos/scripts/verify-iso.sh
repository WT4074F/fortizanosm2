#!/usr/bin/env bash
# Static checks on a built ISO (no VM needed). Read-only.
# Usage: scripts/verify-iso.sh path/to/FortizanOS-*.iso
set -uo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"

ISO=${1:?usage: verify-iso.sh ISO}
FAILS=0
ok()  { echo "  [ OK ] $*"; }
bad() { echo "  [FAIL] $*"; FAILS=$((FAILS+1)); }

echo "== Verifying $ISO"
[ -f "$ISO" ] || { bad "file not found"; exit 1; }

size_mib=$(( $(stat -c %s "$ISO") / 1024 / 1024 ))
[ "$size_mib" -gt 1500 ] && ok "size ${size_mib} MiB" || bad "size ${size_mib} MiB looks too small for a KDE live ISO"

if command -v xorriso >/dev/null; then
    volid=$(xorriso -indev "$ISO" -pvd_info 2>/dev/null | sed -n 's/^Volume Id *: *//p')
    [ "$volid" = "$ISO_VOLID" ] && ok "volume id '$volid'" || bad "volume id '$volid' != '$ISO_VOLID'"

    eltorito=$(xorriso -indev "$ISO" -report_el_torito plain 2>/dev/null)
    grep -q 'BIOS' <<<"$eltorito" && ok "El Torito BIOS boot entry" || bad "no BIOS boot entry"
    grep -q 'UEFI' <<<"$eltorito" && ok "El Torito UEFI boot entry" || bad "no UEFI boot entry"

    listing=$(xorriso -indev "$ISO" -find / -type f 2>/dev/null)
    for f in /EFI/BOOT/BOOTX64.EFI /images/pxeboot/vmlinuz /images/pxeboot/initrd.img; do
        grep -qF "'$f'" <<<"$listing" && ok "contains $f" || bad "missing $f"
    done
    grep -q "'/LiveOS/" <<<"$listing" && ok "contains /LiveOS root image" || bad "missing /LiveOS"
else
    echo "  [SKIP] xorriso not installed — structural checks skipped"
fi

if command -v checkisomd5 >/dev/null; then
    checkisomd5 --verbose "$ISO" >/dev/null 2>&1 && ok "embedded media checksum (checkisomd5)" || bad "checkisomd5 failed"
fi

[ -f "$ISO.sha256" ] && (cd "$(dirname "$ISO")" && sha256sum -c --quiet "$(basename "$ISO").sha256") \
    && ok "sha256 matches" || echo "  [INFO] sha256: $(sha256sum "$ISO" | cut -d' ' -f1)"

[ "$FAILS" -eq 0 ] && echo "ISO VERIFY OK" || echo "ISO VERIFY FAILED ($FAILS)"
exit "$FAILS"
