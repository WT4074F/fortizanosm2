#!/usr/bin/env bash
# Fast (~1 min) check that every group/environment/package named in the
# kickstart exists in the target Fedora release, BEFORE the 30-60 min build.
# Also validates kickstart syntax. Read-only.
set -euo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"
BUILD_DIR="$REPO_ROOT/build"
FLAT="$BUILD_DIR/fortizanos-flat.ks"
mkdir -p "$BUILD_DIR"

"$REPO_ROOT/scripts/generate-overlay-ks.sh"
(cd "$REPO_ROOT/kickstarts" && ksflatten -c fortizanos-live-kde.ks -o "$FLAT")
echo "Flattened kickstart: $FLAT"

echo "-- ksvalidator"
ksvalidator -v "F${FEDORA_RELEASE}" "$FLAT" 2>/dev/null || ksvalidator "$FLAT"

DNF=(dnf -q --releasever="$FEDORA_RELEASE" --forcearch="$ARCH" --repo=fedora --repo=updates)

# Collect %packages lines (skip comments, blanks, exclusions)
mapfile -t ENTRIES < <(awk '/^%packages/{p=1;next} /^%end/{p=0} p' "$FLAT" \
    | sed 's/#.*//' | awk 'NF{print $1}' | grep -v '^-' | sort -u)

GROUPS_AVAIL=$("${DNF[@]}" group list --hidden 2>/dev/null | awk '{print $1}')
ENVS_AVAIL=$("${DNF[@]}" environment list 2>/dev/null | awk '{print $1}')

missing=0
pkgs=()
for e in "${ENTRIES[@]}"; do
    case "$e" in
        @^*) id=${e#@^}; grep -qx "$id" <<<"$ENVS_AVAIL"   || { echo "  MISSING environment: $id"; missing=$((missing+1)); } ;;
        @*)  id=${e#@};  grep -qx "$id" <<<"$GROUPS_AVAIL" || { echo "  MISSING group: $id";       missing=$((missing+1)); } ;;
        *)   pkgs+=("$e") ;;
    esac
done

found=$("${DNF[@]}" repoquery --qf '%{name}\n' "${pkgs[@]}" 2>/dev/null | sort -u)
for p in "${pkgs[@]}"; do
    grep -qx "$p" <<<"$found" || { echo "  MISSING package: $p"; missing=$((missing+1)); }
done

echo "Checked ${#ENTRIES[@]} entries against Fedora ${FEDORA_RELEASE} (${ARCH})."
if [ "$missing" -gt 0 ]; then
    echo "PREFLIGHT FAILED: $missing missing item(s). Fix kickstarts/include/*.ks before building." >&2
    exit 1
fi

# ---- Full dependency resolution (dry run, nothing installed) ---------------
# Proves the package set + exclusions resolve, exactly like the installer
# will, and reports the resulting package count and size.
if [ "${SKIP_RESOLVE:-0}" != 1 ]; then
    echo "-- Resolving the complete package set (dry run, ~1-2 min)"
    mapfile -t EXCLUDES < <(awk '/^%packages/{p=1;next} /^%end/{p=0} p' "$FLAT" \
        | sed 's/#.*//' | awk 'NF{print $1}' | grep '^-' | sed 's/^-//' | sort -u)
    SPECS=()
    for e in "${ENTRIES[@]}"; do SPECS+=("${e/#@^/@}"); done     # dnf5 accepts @env-id
    ROOTDIR=$(mktemp -d)
    excl=$(IFS=,; echo "${EXCLUDES[*]}")
    resolve() {
        dnf --installroot="$ROOTDIR" --use-host-config --releasever="$FEDORA_RELEASE" \
            --repo=fedora --repo=updates --setopt=install_weak_deps=True \
            --exclude="$excl" --assumeno install "$@" 2>&1
    }
    set +e
    out=$(resolve "${SPECS[@]}")
    if grep -q 'No match for argument: @' <<<"$out"; then
        # Some dnf versions want environments as "@^id"; retry that way.
        SPECS2=()
        for e in "${ENTRIES[@]}"; do SPECS2+=("$e"); done
        out=$(resolve "${SPECS2[@]}")
    fi
    set -e
    rm -rf "$ROOTDIR"
    if grep -qiE '^ *Problem|conflicting requests|nothing provides|Failed to resolve' <<<"$out"; then
        grep -iE -A4 'Problem|nothing provides|Failed to resolve' <<<"$out" | head -40 >&2
        echo "PREFLIGHT FAILED: the package set does not resolve (often an excluded package is still required)." >&2
        exit 1
    fi
    if ! grep -qiE 'Transaction Summary|Installing:' <<<"$out"; then
        tail -n 25 <<<"$out" >&2
        echo "PREFLIGHT FAILED: dnf did not produce a transaction (see output above)." >&2
        exit 1
    fi
    summary=$(grep -iE 'Installing: *[0-9]+|Transaction Summary|Total size|After this operation|Installing +[0-9]+ packages' <<<"$out" | head -5)
    echo "${summary:-  (resolved; dnf printed no summary)}" | sed 's/^/  /'
    echo "  Excluded on purpose: ${#EXCLUDES[@]} packages (see docs/PACKAGES.md)"
fi
echo "PREFLIGHT OK"
