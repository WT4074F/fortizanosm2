#!/usr/bin/env bash
# Download the Selawik font (FortizanOS default UI font) into the overlay
# before the ISO is built. Pinned to Microsoft's official 1.01 release and
# verified by SHA-256, so every build gets byte-identical font files.
#
# Selawik: open-source replacement for Segoe UI by Microsoft,
# SIL Open Font License 1.1 (redistribution allowed with the licence).
# Checksum cross-checked against Homebrew's font-selawik cask (v1.01).
set -euo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
URL="https://github.com/microsoft/Selawik/releases/download/1.01/Selawik_Release.zip"
SHA256="3f62c51e05e3b5a1e6241cf92a371f0be2ea1183aa87b30718bbd40832a8d423"
FILES=(selawk.ttf selawkb.ttf selawkl.ttf selawksb.ttf selawksl.ttf)

CACHE="$REPO_ROOT/build/cache"
DEST="$REPO_ROOT/overlay/usr/share/fonts/selawik"     # git-ignored: fetched, not committed
ZIP="$CACHE/Selawik_Release-1.01.zip"

mkdir -p "$CACHE"
if [ ! -f "$ZIP" ] || ! echo "$SHA256  $ZIP" | sha256sum -c --quiet - 2>/dev/null; then
    echo "Downloading Selawik 1.01 from github.com/microsoft/Selawik ..."
    curl -fsSL --retry 3 -o "$ZIP.part" "$URL"
    mv "$ZIP.part" "$ZIP"
fi
if ! echo "$SHA256  $ZIP" | sha256sum -c --quiet -; then
    echo "ERROR: Selawik download does not match the pinned SHA-256 — refusing to use it." >&2
    rm -f "$ZIP"
    exit 1
fi

TMP=$(mktemp -d)
trap 'rm -rf "$TMP"' EXIT
unzip -q -o "$ZIP" -d "$TMP"
mkdir -p "$DEST"
for f in "${FILES[@]}"; do
    src=$(find "$TMP" -type f -iname "$f" | head -n1)
    [ -n "$src" ] || { echo "ERROR: $f not found in the Selawik release archive" >&2; exit 1; }
    install -m 0644 "$src" "$DEST/$f"
done
# The OFL requires the licence to travel with the fonts.
lic=$(find "$TMP" -type f \( -iname 'LICENSE*' -o -iname 'OFL*' \) | head -n1)
if [ -n "$lic" ]; then
    install -m 0644 "$lic" "$DEST/LICENSE.txt"
else
    cat > "$DEST/LICENSE.txt" <<'EOF'
Selawik — Copyright (c) 2015 Microsoft Corporation, with Reserved Font Name Selawik.
Licensed under the SIL Open Font License, Version 1.1: https://openfontlicense.org
Source: https://github.com/microsoft/Selawik (release 1.01)
EOF
fi
echo "Selawik 1.01 verified and staged in ${DEST#"$REPO_ROOT"/} (${#FILES[@]} fonts + licence)"
