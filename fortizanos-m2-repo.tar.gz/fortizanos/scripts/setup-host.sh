#!/usr/bin/env bash
# Requirement 3/5: install Fedora's official image-building tools on a Fedora
# host (or inside the Fedora build container). Only installs packages; it does
# not change SELinux, partitions, or any existing configuration.
set -euo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"

# shellcheck disable=SC1091
. /etc/os-release
if [ "${ID:-}" != fedora ]; then
    echo "ERROR: setup-host.sh must run on Fedora. On other hosts use 'make iso-container'." >&2
    exit 1
fi
if [ "${VERSION_ID:-}" != "$FEDORA_RELEASE" ]; then
    echo "WARNING: host is Fedora ${VERSION_ID}; build.conf targets ${FEDORA_RELEASE}." >&2
    echo "         livemedia-creator --no-virt must run on the SAME release. Use 'make iso-container'." >&2
fi

SUDO=""
[ "$(id -u)" -eq 0 ] || SUDO="sudo"

PKGS=(
    lorax                 # livemedia-creator (Fedora's official live/installer image tool)
    lorax-lmc-novirt      # anaconda deps for --no-virt builds
    pykickstart           # ksflatten / ksvalidator
    anaconda-core anaconda-tui
    xorriso isomd5sum     # ISO inspection + checkisomd5
    curl unzip            # fetch-fonts.sh (Selawik)
    git make
    dnf5-plugins          # repoquery etc. for preflight
    selinux-policy-targeted policycoreutils
)
echo "Installing: ${PKGS[*]}"
$SUDO dnf -y install "${PKGS[@]}"
echo "Build tools installed. Next: make preflight"
