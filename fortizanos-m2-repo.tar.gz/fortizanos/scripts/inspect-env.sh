#!/usr/bin/env bash
# Requirements 1 & 2: inspect the build environment and report CPU/RAM/storage
# plus everything the ISO build depends on. Read-only; changes nothing.
set -uo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"

ok()   { printf '  [ OK ] %s\n' "$*"; }
warn() { printf '  [WARN] %s\n' "$*"; }
bad()  { printf '  [FAIL] %s\n' "$*"; FAILS=$((FAILS+1)); }
FAILS=0

echo "== FortizanOS build environment report ($(date -u +%FT%TZ)) =="

echo "-- Operating system"
# shellcheck disable=SC1091
. /etc/os-release
echo "  ${PRETTY_NAME}"
if [ "${ID:-}" = fedora ] && [ "${VERSION_ID:-}" = "$FEDORA_RELEASE" ]; then
    ok "Fedora ${FEDORA_RELEASE} (matches build.conf)"
elif [ "${ID:-}" = fedora ]; then
    bad "Fedora ${VERSION_ID}, but build.conf targets ${FEDORA_RELEASE}; use 'make iso-container'"
else
    warn "Not Fedora; only the container build ('make iso-container') can work here"
fi

echo "-- CPU"
echo "  $(nproc) logical CPUs — $(lscpu | sed -n 's/^Model name:[[:space:]]*//p' | head -n1)"
[ "$(nproc)" -ge 4 ] && ok "≥4 CPUs" || warn "<4 CPUs: build will be slow (expect 60+ min)"
if grep -qE 'vmx|svm' /proc/cpuinfo; then ok "Hardware virtualisation flags present"; else warn "No VT-x/AMD-V flags (VM testing on this host will be slow or impossible)"; fi
[ -e /dev/kvm ] && ok "/dev/kvm available" || warn "/dev/kvm missing (no local QEMU/KVM smoke test)"

echo "-- Memory"
mem_gib=$(awk '/MemTotal/ {printf "%d", $2/1024/1024}' /proc/meminfo)
echo "  ${mem_gib} GiB RAM, swap: $(awk '/SwapTotal/ {printf "%d MiB", $2/1024}' /proc/meminfo)"
[ "$mem_gib" -ge 8 ] && ok "≥8 GiB RAM" || bad "<8 GiB RAM: build may be OOM-killed"

echo "-- Storage"
work=${WORK_DIR:-/var/tmp}
mkdir -p "$work" 2>/dev/null || true
free_gib=$(df -BG --output=avail "$work" | tail -n1 | tr -dc '0-9')
echo "  ${free_gib} GiB free at $work ($(df --output=fstype "$work" | tail -n1 | tr -d ' '))"
[ "$free_gib" -ge "$MIN_FREE_GIB" ] && ok "≥${MIN_FREE_GIB} GiB free" || bad "Need ≥${MIN_FREE_GIB} GiB free at $work"

echo "-- Tools"
for t in git livemedia-creator ksflatten ksvalidator xorriso checkisomd5 sha256sum; do
    if command -v "$t" >/dev/null; then ok "$t"; else warn "$t not installed (run scripts/setup-host.sh on Fedora)"; fi
done
for t in podman docker; do command -v "$t" >/dev/null && ok "$t (container build possible)"; done
command -v VBoxManage >/dev/null && ok "VBoxManage $(VBoxManage --version)" || warn "VirtualBox not installed (needed for 'make vbox-test')"

echo "-- Security / devices"
if command -v getenforce >/dev/null; then
    se=$(getenforce)
    [ "$se" = Enforcing ] && warn "SELinux Enforcing: livemedia-creator --no-virt needs Permissive during the build (see docs/BUILD.md)" || ok "SELinux: $se"
fi
[ -e /dev/loop-control ] && ok "loop devices available" || bad "no /dev/loop-control (loop devices required)"
[ "$(id -u)" -eq 0 ] && ok "running as root" || warn "not root (the build itself must run as root)"

echo "-- Network"
if curl -fsS -m 15 -o /dev/null "https://mirrors.fedoraproject.org/metalink?repo=fedora-${FEDORA_RELEASE}&arch=${ARCH}"; then
    ok "Fedora metalink reachable"
else
    bad "Cannot reach mirrors.fedoraproject.org — the build downloads ~3 GiB of RPMs"
fi

echo
[ "$FAILS" -eq 0 ] && echo "RESULT: environment can build FortizanOS" || echo "RESULT: ${FAILS} blocking problem(s) — see [FAIL] lines"
exit "$FAILS"
