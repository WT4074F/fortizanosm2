#!/usr/bin/env bash
# Create and boot a VirtualBox VM for testing a FortizanOS ISO.
#
# Usage: scripts/vbox-test.sh ISO [--bios] [--name NAME] [--no-start]
#   default firmware is UEFI (the common case); --bios tests legacy boot.
#
# Safety: if a VM with the chosen name already exists the script STOPS.
# It never deletes VMs or disks. Remove an old test VM yourself with:
#   VBoxManage unregistervm NAME --delete      (destroys its disk)
set -euo pipefail

ISO=""; FIRMWARE=efi; NAME=""; START=1
while [ $# -gt 0 ]; do
    case "$1" in
        --bios) FIRMWARE=bios ;;
        --name) NAME=$2; shift ;;
        --no-start) START=0 ;;
        -*) echo "unknown option $1" >&2; exit 2 ;;
        *) ISO=$1 ;;
    esac
    shift
done
[ -n "$ISO" ] && [ -f "$ISO" ] || { echo "usage: $0 ISO [--bios] [--name NAME] [--no-start]" >&2; exit 2; }
command -v VBoxManage >/dev/null || { echo "ERROR: VirtualBox (VBoxManage) not installed" >&2; exit 1; }

ISO=$(readlink -f "$ISO")
NAME=${NAME:-FortizanOS-M1-${FIRMWARE}}

if VBoxManage showvminfo "$NAME" >/dev/null 2>&1; then
    echo "ERROR: VM '$NAME' already exists. Not touching it." >&2
    echo "       Use --name for a new VM, or delete the old one yourself:" >&2
    echo "       VBoxManage unregistervm '$NAME' --delete" >&2
    exit 1
fi

VM_DIR=$(VBoxManage list systemproperties | sed -n 's/^Default machine folder: *//p')
DISK="$VM_DIR/$NAME/$NAME.vdi"

VBoxManage createvm --name "$NAME" --ostype Fedora_64 --register
VBoxManage modifyvm "$NAME" \
    --memory 4096 --cpus 2 --vram 128 \
    --graphicscontroller vmsvga \
    --accelerate-3d on \
    --firmware "$FIRMWARE" \
    --nic1 nat \
    --rtc-use-utc on \
    --boot1 dvd --boot2 disk --boot3 none --boot4 none
VBoxManage createmedium disk --filename "$DISK" --size 40960 --format VDI
VBoxManage storagectl "$NAME" --name SATA --add sata --controller IntelAhci --portcount 2
VBoxManage storageattach "$NAME" --storagectl SATA --port 0 --device 0 --type hdd --medium "$DISK"
VBoxManage storageattach "$NAME" --storagectl SATA --port 1 --device 0 --type dvddrive --medium "$ISO"

echo "Created VM '$NAME' ($FIRMWARE, 4 GiB RAM, 2 CPU, 40 GiB disk, NAT)."
[ "$START" -eq 1 ] && VBoxManage startvm "$NAME" --type gui
echo "Follow tests/TEST-PLAN.md. Inside the VM run: tests/verify-system.sh"
