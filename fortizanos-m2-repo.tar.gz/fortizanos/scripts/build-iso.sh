#!/usr/bin/env bash
# Requirement 10: build the FortizanOS live ISO with livemedia-creator (lorax).
#
# Must run as root on Fedora ${FEDORA_RELEASE} (host or the official container,
# see build-in-container.sh). Each build goes to its own timestamped directory
# under out/, so nothing from a previous build is ever overwritten or deleted.
set -euo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"

export BUILD_ID=${BUILD_ID:-$(date -u +%Y%m%d.%H%M)}
OUT_ROOT=${OUT_DIR:-$REPO_ROOT/out}
RESULT_DIR="$OUT_ROOT/$BUILD_ID"
# livemedia-creator refuses to start if --resultdir exists, and it creates the
# --logfile directory first, so logs must live OUTSIDE the result dir.
LOG_DIR="$OUT_ROOT/$BUILD_ID-logs/logs"
WORK_DIR=${WORK_DIR:-/var/tmp/fortizanos-build}
BUILD_DIR="$REPO_ROOT/build"
FLAT="$BUILD_DIR/fortizanos-flat.ks"

die() { echo "ERROR: $*" >&2; exit 1; }

# ---- Guard rails (fail early with a clear message) --------------------------
[ "$(id -u)" -eq 0 ] || die "must run as root (sudo make iso)"
# shellcheck disable=SC1091
. /etc/os-release
[ "${ID:-}" = fedora ] || die "must run on Fedora (use 'make iso-container' elsewhere)"
[ "${VERSION_ID:-}" = "$FEDORA_RELEASE" ] || die "host is Fedora ${VERSION_ID}, build.conf wants ${FEDORA_RELEASE} (use 'make iso-container')"
for t in livemedia-creator ksflatten; do command -v "$t" >/dev/null || die "$t missing — run scripts/setup-host.sh"; done
if command -v getenforce >/dev/null && [ "$(getenforce)" = Enforcing ]; then
    die "SELinux is Enforcing. livemedia-creator --no-virt needs Permissive for the build:
       sudo setenforce 0   # temporary, until reboot
       ...build...
       sudo setenforce 1   # restore afterwards
     This script will not change SELinux for you."
fi
mkdir -p "$WORK_DIR" "$OUT_ROOT" "$BUILD_DIR"
free_gib=$(df -BG --output=avail "$WORK_DIR" | tail -n1 | tr -dc '0-9')
[ "$free_gib" -ge "$MIN_FREE_GIB" ] || die "only ${free_gib} GiB free in $WORK_DIR (need ${MIN_FREE_GIB})"
[ ! -e "$RESULT_DIR" ] || die "$RESULT_DIR already exists; set BUILD_ID to something new"

# ---- Prepare the reproducible input ------------------------------------------
"$REPO_ROOT/scripts/fetch-fonts.sh"          # Selawik, pinned + checksum-verified
"$REPO_ROOT/scripts/generate-overlay-ks.sh"
(cd "$REPO_ROOT/kickstarts" && ksflatten -c fortizanos-live-kde.ks -o "$FLAT")
command -v ksvalidator >/dev/null && ksvalidator "$FLAT"

# ---- Build ------------------------------------------------------------------
TMPDIR_LMC=$(mktemp -d "$WORK_DIR/lmc.XXXXXX")
echo "Building ${ISO_NAME} (build ${BUILD_ID}); log: ${LOG_DIR}/"
start=$(date +%s)

# --resultdir must not exist yet; livemedia-creator creates it.
livemedia-creator \
    --ks "$FLAT" \
    --no-virt \
    --make-iso \
    --iso-only \
    --iso-name "$ISO_NAME" \
    --project "$DISTRO_NAME" \
    --releasever "$FEDORA_RELEASE" \
    --volid "$ISO_VOLID" \
    --tmp "$TMPDIR_LMC" \
    --resultdir "$RESULT_DIR" \
    --logfile "$LOG_DIR/livemedia.log"

# ---- Record what was built ---------------------------------------------------
ISO="$RESULT_DIR/$ISO_NAME"
[ -f "$ISO" ] || die "livemedia-creator finished but $ISO is missing — see $LOG_DIR/"
cp "$FLAT" "$RESULT_DIR/fortizanos-flat.ks"
(cd "$RESULT_DIR" && sha256sum "$ISO_NAME" > "$ISO_NAME.sha256")
{
    echo "distro=$DISTRO_NAME $DISTRO_VERSION"
    echo "build_id=$BUILD_ID"
    echo "fedora_release=$FEDORA_RELEASE"
    echo "git_commit=$(git -C "$REPO_ROOT" -c safe.directory='*' rev-parse HEAD 2>/dev/null || echo unknown)"
    echo "lorax=$(rpm -q lorax)"
    echo "anaconda=$(rpm -q anaconda-core)"
    echo "builder=$(uname -r) $(. /etc/os-release; echo "$PRETTY_NAME")"
    echo "duration_min=$(( ($(date +%s) - start) / 60 ))"
} > "$RESULT_DIR/build-info.txt"

# livemedia-creator leaves its scratch here; it is our own temp dir.
rm -rf "$TMPDIR_LMC"

"$REPO_ROOT/scripts/verify-iso.sh" "$ISO" \
    || echo "WARNING: static ISO checks reported problems (above); ISO kept for boot testing"
echo
echo "DONE: $ISO"
