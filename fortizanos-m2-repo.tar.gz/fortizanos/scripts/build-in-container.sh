#!/usr/bin/env bash
# Build the ISO inside the official Fedora container. Works on any Linux host
# with podman or docker (Fedora of another release, Ubuntu, CI runners).
#
# Needs --privileged + /dev for loop devices. On SELinux-enforcing hosts
# (e.g. Fedora), set SELinux to Permissive for the duration of the build —
# build-iso.sh will stop and tell you if this is needed.
set -euo pipefail

REPO_ROOT=$(cd "$(dirname "${BASH_SOURCE[0]}")/.." && pwd)
# shellcheck source=../build.conf
source "$REPO_ROOT/build.conf"

ENGINE=${CONTAINER_ENGINE:-$(command -v podman || command -v docker || true)}
[ -n "$ENGINE" ] || { echo "ERROR: need podman or docker" >&2; exit 1; }

WORK_HOST=${WORK_HOST:-/var/tmp/fortizanos-build}
mkdir -p "$WORK_HOST"

echo "Using $ENGINE with $FEDORA_CONTAINER"
exec "$ENGINE" run --rm --privileged \
    -v /dev:/dev \
    -v "$REPO_ROOT:/src:z" \
    -v "$WORK_HOST:/var/tmp/fortizanos-build:z" \
    -e BUILD_ID="${BUILD_ID:-}" \
    -w /src \
    "$FEDORA_CONTAINER" \
    bash -euc '
        dnf -y upgrade --refresh
        /src/scripts/setup-host.sh
        BUILD_ID=${BUILD_ID:-$(date -u +%Y%m%d.%H%M)} /src/scripts/build-iso.sh
    '
