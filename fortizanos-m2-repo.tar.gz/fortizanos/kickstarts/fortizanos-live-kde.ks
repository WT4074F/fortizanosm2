# =============================================================================
# FortizanOS — Live KDE Plasma ISO (Milestone 1)
# Base: Fedora Linux (release set in build.conf), KDE Plasma Desktop
#
# Top-level kickstart. Do not feed this file to livemedia-creator directly:
# scripts/build-iso.sh generates the overlay include and flattens everything
# with ksflatten into build/fortizanos-flat.ks.
#
# Order matters: %post sections run in the order they appear.
# =============================================================================

%include include/repos.ks
%include include/live-base.ks
%include include/kde.ks
%include include/overlay.generated.ks
%include include/fortizanos.ks
%include include/theme-cleanup.ks
