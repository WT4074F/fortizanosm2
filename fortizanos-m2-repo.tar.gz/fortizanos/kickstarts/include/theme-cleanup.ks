# -----------------------------------------------------------------------------
# Theme cleanup (Milestone 2, owner request): Fortizan Aero is the only theme.
#
# Removed: every other global theme, Plasma style, colour scheme, window
# decoration, wallpaper and extra icon/cursor theme.
#
# Kept because KDE itself needs them (they do not appear as alternatives in
# normal use, but deleting them breaks the desktop):
#   org.kde.breeze.desktop  — provides lock screen, logout and OSD screens
#                             that Fortizan Aero inherits
#   desktoptheme/default    — fallback for any Plasma graphic we don't draw
#   Breeze widget style + Breeze decoration plugin (inside the "breeze"
#   package, required by Plasma) — app controls and performance mode
#   breeze / hicolor / Adwaita icons — Fortizan Aero icons inherit from
#   Breeze; GTK apps (Firefox) need Adwaita
#
# An RPM macro (%_netsharedpath) stops package updates from putting the
# removed files back. Everything removed is listed in
# /usr/lib/fortizanos/removed-themes.txt; `dnf reinstall <package>` after
# deleting /etc/rpm/macros.fortizanos-themes restores any of it.
# -----------------------------------------------------------------------------

%post --interpreter=/usr/bin/bash --erroronfail
set -u
LOG=/usr/lib/fortizanos/removed-themes.txt
: > "$LOG"

keep_only() {   # keep_only DIR NAME... — remove every entry of DIR not named
    local dir=$1 e n k; shift
    [ -d "$dir" ] || return 0
    for e in "$dir"/* "$dir"/.[!.]*; do
        [ -e "$e" ] || continue
        n=${e##*/}
        for k in "$@"; do [ "$n" = "$k" ] && continue 2; done
        echo "$e" >> "$LOG"
        rm -rf -- "$e"
    done
}

remove_if_present() {
    local p
    for p in "$@"; do
        [ -e "$p" ] || continue
        echo "$p" >> "$LOG"
        rm -rf -- "$p"
    done
}

# Only clean a folder when the fallback KDE needs from it is really there;
# otherwise leave it alone and report it (safer than breaking the desktop).
clean_with_fallback() {   # DIR FALLBACK KEEP...
    local dir=$1 fallback=$2; shift 2
    if [ -e "$dir/$fallback" ]; then
        keep_only "$dir" "$@"
    else
        echo "WARNING: $dir/$fallback not found; left $dir untouched"
    fi
}
clean_with_fallback /usr/share/plasma/look-and-feel org.kde.breeze.desktop  org.fortizanos.aero.desktop org.kde.breeze.desktop
clean_with_fallback /usr/share/plasma/desktoptheme  default                 fortizan-aero default
keep_only /usr/share/color-schemes         FortizanAero.colors
keep_only /usr/share/aurorae/themes        FortizanAero
keep_only /usr/share/wallpapers            FortizanAero
remove_if_present \
    /usr/share/kwin/decorations/kwin4_decoration_qml_plastik \
    /usr/share/icons/breeze-dark \
    /usr/share/icons/Breeze_Light \
    /usr/share/icons/oxygen \
    /usr/share/icons/KDE_Classic \
    /usr/share/icons/Oxygen_Black /usr/share/icons/Oxygen_Blue /usr/share/icons/Oxygen_White \
    /usr/share/icons/Oxygen_Yellow /usr/share/icons/Oxygen_Zion

# Our own theme must still be there (fallbacks are guarded above).
for p in /usr/share/plasma/look-and-feel/org.fortizanos.aero.desktop \
         /usr/share/plasma/desktoptheme/fortizan-aero \
         /usr/share/icons/breeze /usr/share/icons/breeze_cursors; do
    [ -e "$p" ] || { echo "ERROR: required theme component missing: $p"; exit 1; }
done

# Keep them removed when the owning packages update.
if [ -s "$LOG" ]; then
    {
        echo "# FortizanOS: theme files intentionally not installed (see /usr/lib/fortizanos/removed-themes.txt)."
        echo "# Delete this file and 'dnf reinstall' the package to get a theme back."
        printf '%%_netsharedpath %s\n' "$(paste -sd: "$LOG")"
    } > /etc/rpm/macros.fortizanos-themes
fi
echo "Theme cleanup: removed $(wc -l < "$LOG") theme items"
%end
