# -----------------------------------------------------------------------------
# FortizanOS distribution configuration (Milestone 1).
# Runs AFTER overlay.generated.ks, so overlay files and
# /usr/lib/fortizanos/build-info already exist here.
# -----------------------------------------------------------------------------

%post --interpreter=/usr/bin/bash --erroronfail
set -u
source /usr/lib/fortizanos/build-info

echo "== FortizanOS ${DISTRO_VERSION} configuration (git ${GIT_COMMIT}) =="

# --- 1. Identity / os-release -----------------------------------------------
# ID stays 'fedora' on purpose for M1: anaconda selects its Fedora KDE
# profile (EFI dir, defaults) from os-release ID/VARIANT_ID. Changing ID
# without a matching installer profile breaks UEFI installs.
# See docs/DECISIONS.md D-003.
osr=/usr/lib/os-release
sed -i \
    -e "s|^NAME=.*|NAME=\"${DISTRO_NAME}\"|" \
    -e "s|^PRETTY_NAME=.*|PRETTY_NAME=\"${DISTRO_NAME} ${DISTRO_VERSION} (Fedora ${FEDORA_RELEASE} KDE Plasma base)\"|" \
    "$osr"
grep -q '^FORTIZANOS_VERSION=' "$osr" || cat >> "$osr" <<EOF
FORTIZANOS_VERSION="${DISTRO_VERSION}"
FORTIZANOS_CODENAME="${DISTRO_CODENAME}"
FORTIZANOS_BUILD_ID="${BUILD_ID}"
EOF
grep -q "^NAME=\"${DISTRO_NAME}\"" "$osr" || { echo "ERROR: os-release branding failed"; exit 1; }

# --- 2. Package management (requirement 9) ------------------------------------
# dnf5 reads [main] from /etc/dnf/dnf.conf. Keep fedora + updates enabled,
# GPG checking on (fedora-repos default), sensible parallelism/retention.
dnfconf=/etc/dnf/dnf.conf
grep -q '^\[main\]' "$dnfconf" 2>/dev/null || printf '[main]\n' >> "$dnfconf"
if ! grep -q 'FortizanOS package-management defaults' "$dnfconf"; then
    cat >> "$dnfconf" <<'EOF'

# --- FortizanOS package-management defaults (Milestone 1) ---
# Faster, still metalink-verified downloads
max_parallel_downloads=10
# Keep the running kernel plus two fallbacks
installonly_limit=3
# Fail loudly if a repo is unreachable instead of half-updating
skip_if_unavailable=False
EOF
fi
# Sanity: official repos present and GPG-checked
# Fedora 45+ ships repo files in /usr/share/dnf5/repos.d (older: /etc/yum.repos.d)
repo_files=$(ls /etc/yum.repos.d/*.repo /usr/share/dnf5/repos.d/*.repo 2>/dev/null)
for r in fedora updates; do
    f=$(grep -l "^\[${r}\]" $repo_files /dev/null | head -n1)
    [ -n "$f" ] || { echo "ERROR: repo '$r' missing"; exit 1; }
    grep -Eq '^gpgcheck=(1|true|True)' "$f" || { echo "ERROR: gpgcheck not enabled for '$r'"; exit 1; }
done

# --- 3. Flatpak (requirement 8) -----------------------------------------------
# Try now (build host normally has network); the first-boot service is the
# fallback and also covers systems where this step could not reach Flathub.
mkdir -p /var/lib/fortizanos
if timeout 120 flatpak remote-add --system --if-not-exists flathub \
        https://dl.flathub.org/repo/flathub.flatpakrepo; then
    echo "Flathub remote added at build time"
    touch /var/lib/fortizanos/flathub-configured
else
    echo "WARNING: could not add Flathub at build time; first-boot service will retry"
fi
systemctl enable fortizanos-flathub.service

# --- 4. Btrfs (requirement 7) ---------------------------------------------------
# Installer default comes from /etc/anaconda/conf.d/90-fortizanos-storage.conf
# (shipped by the overlay). Verify it landed.
test -f /etc/anaconda/conf.d/90-fortizanos-storage.conf \
    || { echo "ERROR: anaconda Btrfs config missing"; exit 1; }
command -v mkfs.btrfs >/dev/null || { echo "ERROR: btrfs-progs missing"; exit 1; }

# --- 5. Desktop identity (Milestone 2) ----------------------------------------
# All theme files arrive via the overlay; verify they landed and that the
# KDE components they rely on are installed.
for p in /usr/share/plasma/desktoptheme/fortizan-aero/metadata.json \
         /usr/share/plasma/look-and-feel/org.fortizanos.aero.desktop/metadata.json \
         /usr/share/aurorae/themes/FortizanAero/decoration.svg \
         /usr/share/color-schemes/FortizanAero.colors \
         /usr/share/icons/FortizanAero/index.theme \
         /usr/share/wallpapers/FortizanAero/metadata.json \
         /etc/xdg/kdeglobals /etc/xdg/kwinrc /etc/xdg/plasmarc \
         /usr/bin/fortizan-effects; do
    [ -e "$p" ] || { echo "ERROR: missing $p"; exit 1; }
done
rpm -q aurorae >/dev/null || { echo "ERROR: aurorae (window decoration engine) not installed"; exit 1; }
command -v kwriteconfig6 >/dev/null || { echo "ERROR: kwriteconfig6 missing (needed by fortizan-effects)"; exit 1; }
# Default UI font: Selawik (bundled by scripts/fetch-fonts.sh). Required.
for f in selawk.ttf selawkb.ttf selawksb.ttf LICENSE.txt; do
    [ -f "/usr/share/fonts/selawik/$f" ] || { echo "ERROR: Selawik font file missing: $f"; exit 1; }
done
[ -f /etc/fonts/conf.d/59-fortizanos-segoe-ui.conf ] || { echo "ERROR: font rule missing"; exit 1; }
fc-cache -f >/dev/null 2>&1 || true
fc-list | grep -qi selawik || { echo "ERROR: fontconfig does not see Selawik"; exit 1; }
echo "UI font: $(fc-match Selawik) ; 'Segoe UI' requests -> $(fc-match 'Segoe UI')"
# GTK apps (e.g. Firefox) read icon caches; refresh them for the new icons.
for d in /usr/share/icons/hicolor /usr/share/icons/FortizanAero; do
    command -v gtk-update-icon-cache >/dev/null && gtk-update-icon-cache -qf "$d" || true
done

# --- 6. Package manifest (reproducibility record) ---------------------------
rpm -qa --qf '%{NAME}-%{EPOCHNUM}:%{VERSION}-%{RELEASE}.%{ARCH}\n' | sort \
    > /usr/lib/fortizanos/package-manifest.txt
echo "Packages in image: $(wc -l < /usr/lib/fortizanos/package-manifest.txt)"

# rpm queries recreate these; not wanted on the image
rm -f /var/lib/rpm/__db*
echo "== FortizanOS configuration complete =="
%end
