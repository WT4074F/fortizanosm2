# -----------------------------------------------------------------------------
# Live-media base. Adapted from Fedora's fedora-live-base.ks, trimmed to what a
# bootable live ISO + installer needs. Keep this close to upstream so Fedora
# fixes can be ported easily.
# -----------------------------------------------------------------------------

lang en_US.UTF-8
# UK keyboard by default (owner decision); the installer still offers every layout.
keyboard --vckeymap=gb --xlayouts='gb'
timezone Etc/UTC
selinux --enforcing
firewall --enabled --service=mdns
xconfig --startxonboot
zerombr
clearpart --all
# Size of the live root filesystem image (MiB) before compression.
# This is NOT the installed filesystem — see docs/DECISIONS.md (Btrfs).
part / --size=14336 --fstype=ext4
services --enabled=NetworkManager,ModemManager --disabled=sshd
network --bootproto=dhcp --device=link --activate --hostname=fortizanos
rootpw --lock
shutdown

%packages
# Core system
@core
@standard
@base-x
@fonts
@hardware-support
@multimedia
@printing
@guest-desktop-agents

# Kernel
kernel
kernel-modules
kernel-modules-extra

# Live boot support
dracut-live
livesys-scripts
glibc-all-langpacks

# Bootloaders required by lorax's live ISO templates (BIOS + UEFI/Secure Boot)
grub2-efi-x64
grub2-efi-x64-cdboot
grub2-pc
grub2-pc-modules
grub2-tools
grub2-tools-extra
shim-x64
efibootmgr

# Installer (the point of a live image is to install)
anaconda
anaconda-install-env-deps
anaconda-live
@anaconda-tools

# Upstream Fedora drops these from live media
-fcoe-utils
-device-mapper-multipath
-sdubby
%end

%post --interpreter=/usr/bin/bash
# --- Generic live-media housekeeping (from fedora-live-base.ks) -------------

# Enable the live system session scripts (creates 'liveuser', autologin).
systemctl enable livesys.service
systemctl enable livesys-late.service

# Keep throwaway data out of the live overlay.
grep -qs '^vartmp' /etc/fstab || echo 'vartmp   /var/tmp    tmpfs   defaults   0  0' >> /etc/fstab

# Pre-build the man page index so 'man -k' works on the live system.
/usr/bin/mandb >/dev/null 2>&1 || true

# Each installed system must generate its own identity/seed.
rm -f /core*
rm -f /var/lib/systemd/random-seed
rm -f /boot/*-rescue*
rm -f /etc/machine-id
touch /etc/machine-id

echo 'File created by kickstart. See systemd-update-done.service(8).' \
    | tee /etc/.updated >/var/.updated
%end
