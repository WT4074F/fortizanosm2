# -----------------------------------------------------------------------------
# Package sources used AT BUILD TIME.
# $releasever comes from livemedia-creator --releasever (build.conf FEDORA_RELEASE).
# Metalinks are used (not plain mirrorlists) because they carry repomd.xml
# checksums, so a stale or broken mirror is rejected instead of silently used.
#
# The installed/live system's own repo config comes from the fedora-repos
# package, not from this file.
# -----------------------------------------------------------------------------

url --metalink="https://mirrors.fedoraproject.org/metalink?repo=fedora-$releasever&arch=$basearch"
repo --name=fedora  --metalink="https://mirrors.fedoraproject.org/metalink?repo=fedora-$releasever&arch=$basearch"
repo --name=updates --metalink="https://mirrors.fedoraproject.org/metalink?repo=updates-released-f$releasever&arch=$basearch"
