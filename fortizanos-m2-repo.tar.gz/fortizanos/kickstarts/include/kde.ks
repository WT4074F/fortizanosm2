# -----------------------------------------------------------------------------
# Desktop: Fedora KDE Plasma base, trimmed to one application per job
# (Milestone 2 "lightweight" rule). Package lists explained in
# docs/PACKAGES.md. Theme files come from overlay/, not from packages.
# -----------------------------------------------------------------------------

%packages
@^kde-desktop-environment
@firefox
fedora-release-kde-desktop

# Window decoration engine for the Fortizan Aero title bars (already part of
# Fedora KDE; listed so the theme never loses its dependency silently)
aurorae
# kwriteconfig6 / kreadconfig6, used by fortizan-effects
kf6-kconfig

# Office suite — LibreOffice only (owner decision), core three apps
libreoffice-writer
libreoffice-calc
libreoffice-impress

# Flatpak (requirement 8) — runtime + Discover backend
flatpak
plasma-discover-flatpak

# Btrfs userspace tools (requirement 7) — needed on the installed system
btrfs-progs

# VirtualBox guest support (resolution, clipboard) for the test matrix
virtualbox-guest-additions

# Basic system utilities
bash-completion
curl
htop
less
lsof
man-db
man-pages
nano
pciutils
rsync
tar
unzip
usbutils
vim-minimal
wget2-wget
zip

# ---- Removed for a lighter system (Milestone 2) -----------------------------
# Background services: the PIM stack runs Akonadi, which in Fedora's default
# set starts a full MariaDB database server per user. Largest idle-RAM cost.
-akonadi-server
-akonadi-server-mysql
-mariadb-server
-kdepim-runtime
-kdepim-addons
-kmail
-kmail-account-wizard
-kontact
-korganizer
-kaddressbook
-akonadi-import-wizard
-akregator
-pim-sieve-editor
-pim-data-exporter
-kleopatra
# KDE Connect keeps a daemon running permanently
-kde-connect
-kdeconnectd
# Duplicates of kept apps
-krusader
-kfind
-digikam
# Niche or heavy; installable from Discover when wanted
-k3b
-ktorrent
-neochat
-qrca
-kmouth
-krdc
-krfb
-kamoso
-skanpage
-kdebugsettings
-kjournald
-kmahjongg
-kpat
-kmines
%end

%post --interpreter=/usr/bin/bash
# Tell livesys to configure a KDE session for the live user.
if [ -f /etc/sysconfig/livesys ]; then
    sed -i 's/^livesys_session=.*/livesys_session="kde"/' /etc/sysconfig/livesys
else
    echo 'livesys_session="kde"' > /etc/sysconfig/livesys
fi
%end
