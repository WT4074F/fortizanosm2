#!/usr/bin/env python3
"""Generate every FortizanOS Aero visual asset from tools/palette.py.

Outputs (committed to git, so the ISO build needs no Python):
  overlay/usr/share/plasma/desktoptheme/fortizan-aero/   Plasma style (taskbar, pop-ups)
  overlay/usr/share/aurorae/themes/FortizanAero/         window decoration
  overlay/usr/share/color-schemes/FortizanAero.colors    application colours
  overlay/usr/share/wallpapers/FortizanAero/             wallpaper (needs rsvg-convert)
  overlay/usr/share/icons/FortizanAero/                  branded glossy icons
  build/previews/                                        PNG previews (not committed)

Usage: python3 tools/gen-theme.py [--no-raster]
"""
import json
import os
import shutil
import subprocess
import sys

sys.path.insert(0, os.path.dirname(__file__))
from palette import *            # noqa: E402,F401,F403
from svgframe import SvgDoc, FrameStyle, add_frame   # noqa: E402

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
OV = os.path.join(ROOT, "overlay", "usr", "share")
PREV = os.path.join(ROOT, "build", "previews")
WHITE = (255, 255, 255)
VERSION = "0.2.0"
RASTER = "--no-raster" not in sys.argv


def write(path, text):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, "w", encoding="utf-8") as f:
        f.write(text)


def raster(svg, png, w=None, h=None):
    if not RASTER:
        return
    os.makedirs(os.path.dirname(png), exist_ok=True)
    cmd = ["rsvg-convert", svg, "-o", png]
    if w:
        cmd[1:1] = ["-w", str(w)]
    if h:
        cmd[1:1] = ["-h", str(h)]
    subprocess.run(cmd, check=True)


# ---------------------------------------------------------------- Plasma style
def glass(base_top, base_bottom, alpha, sheen_split=None):
    """Vertical glass gradient. sheen_split adds the classic upper/lower glass split."""
    if sheen_split:
        return [(0.0, mix(base_top, WHITE, 0.10), alpha),
                (sheen_split - 0.02, base_top, alpha),
                (sheen_split + 0.02, mix(base_top, base_bottom, 0.55), alpha),
                (1.0, base_bottom, alpha)]
    return [(0.0, base_top, alpha), (1.0, base_bottom, alpha)]


def plasma_frames(alpha_scale):
    """alpha_scale=1 -> translucent glass; None -> opaque (blur off)."""
    def A(a):
        return 1.0 if alpha_scale is None else a
    # Longhorn 4074: transparent smoked glass for the shell, white glass edge
    # on top, glassy upper/lower split (reflection), dark outline.
    return {
        "widgets/panel-background": dict(
            style=FrameStyle(radius=3, stops=glass(SMOKE_LIGHT, SMOKE, A(ALPHA_TASKBAR), 0.5),
                             border=(GLASS_EDGE, 0.60), border_top=(WHITE, 0.42), highlight=(SKY, 0.30),
                             sheen=(WHITE, 0.12)),
            mask=True, shadow=None, hint_stretch=True),
        "dialogs/background": dict(
            style=FrameStyle(radius=8, stops=glass(SMOKE_LIGHT, SMOKE, A(ALPHA_POPUP)),
                             border=(WHITE, 0.30), highlight=(WHITE, 0.22), sheen=(WHITE, 0.08)),
            mask=True, shadow=(16, 0.40), hint_stretch=True),
        "widgets/tooltip": dict(
            style=FrameStyle(radius=6, stops=glass(SMOKE_LIGHT, SMOKE, A(ALPHA_TOOLTIP)),
                             border=(WHITE, 0.28), highlight=(WHITE, 0.18)),
            mask=True, shadow=(10, 0.36), hint_stretch=True),
        "widgets/background": dict(
            style=FrameStyle(radius=8, stops=glass(SMOKE_LIGHT, SMOKE, A(ALPHA_WIDGET)),
                             border=(WHITE, 0.26), highlight=(WHITE, 0.16)),
            mask=True, shadow=(10, 0.28), hint_stretch=True),
    }


def task_states():
    """Task-bar buttons: Longhorn-style glossy capsules, luminous when focused."""
    return {
        "normal": FrameStyle(radius=4, stops=[(0, WHITE, 0.02), (1, WHITE, 0.02)]),
        "hover": FrameStyle(radius=4, stops=glass(GLASS_CLEAR, GLASS_ICE, 0.22, 0.5),
                            border=(WHITE, 0.45), highlight=(WHITE, 0.35)),
        "focus": FrameStyle(radius=4, stops=glass(GLASS_CLEAR, mix(GLASS_ICE, SKY, 0.4), 0.38, 0.5),
                            border=(WHITE, 0.60), border_top=(WHITE, 0.85), highlight=(WHITE, 0.45),
                            glow=(CYAN, 0.30)),
        "attention": FrameStyle(radius=4, stops=glass(mix(AMBER, WHITE, 0.15), mix(AMBER, NAVY, 0.55), 0.75, 0.5),
                                border=(AMBER, 0.85), highlight=(WHITE, 0.30)),
        "minimized": FrameStyle(radius=4, stops=[(0, SLATE, 0.12), (1, SLATE, 0.18)],
                                border=(SLATE, 0.35)),
    }


def build_plasma_style():
    base = os.path.join(OV, "plasma", "desktoptheme", "fortizan-aero")
    if os.path.isdir(base):
        shutil.rmtree(base)
    meta = {
        "KPlugin": {
            "Authors": [{"Name": "FortizanOS Project"}],
            "Description": "Frosted dark-blue glass inspired by the experimental Longhorn 4074 Aero direction",
            "Id": "fortizan-aero",
            "License": "CC-BY-SA-4.0",
            "Name": "Fortizan Aero",
            "Version": VERSION,
        },
        "X-Plasma-API-Minimum-Version": "6.0",
    }
    write(os.path.join(base, "metadata.json"), json.dumps(meta, indent=4) + "\n")
    # plasmarc: ask KWin for blur + contrast behind our translucent graphics.
    write(os.path.join(base, "plasmarc"),
          "[ContrastEffect]\nenabled=true\ncontrast=0.45\nintensity=1.15\nsaturation=1.6\n\n"
          "[BlurBehindEffect]\nenabled=true\n\n"
          "[AdaptiveTransparency]\nenabled=false\n")
    write(os.path.join(base, "colors"), plasma_colors())

    for variant, scale in (("", None), ("translucent", 1)):
        for rel, spec in plasma_frames(scale).items():
            doc = SvgDoc()
            add_frame(doc, "", spec["style"], 2, 2,
                      mask_prefix="mask" if spec["mask"] else None, shadow=spec["shadow"])
            if spec["hint_stretch"]:
                doc.group("hint-stretch-borders", doc.w + 4, 2, 4, 4, "")
            out = os.path.join(base, variant, rel + ".svg")
            write(out, doc.render())
            raster(out, os.path.join(PREV, "plasma", (variant or "opaque") + "-" + rel.replace("/", "_") + ".png"))

    # Task buttons (same for both variants: they sit on the panel's glass)
    doc = SvgDoc()
    y = 2
    for prefix, st in task_states().items():
        _, h = add_frame(doc, prefix, st, 2, y)
        y += h + 6
    doc.group("hint-stretch-borders", doc.w + 4, 2, 4, 4, "")
    out = os.path.join(base, "widgets", "tasks.svg")
    write(out, doc.render())
    raster(out, os.path.join(PREV, "plasma", "tasks.png"))
    return base


def plasma_colors():
    """Colours Plasma uses for text and icons drawn ON the dark glass."""
    t, m = TEXT_ON_GLASS, TEXT_MUTED_ON_GLASS
    groups = {
        "Window": NAVY, "View": NAVY_DEEP, "Button": NAVY_SOFT, "Selection": SELECTION,
        "Tooltip": NAVY_SOFT, "Complementary": NAVY_DEEP, "Header": NAVY_SOFT,
    }
    out = []
    for g, bg in groups.items():
        fg = WHITE if g == "Selection" else t
        out.append(f"[Colors:{g}]\n"
                   f"BackgroundNormal={kde(bg)}\nBackgroundAlternate={kde(mix(bg, WHITE, 0.06))}\n"
                   f"ForegroundNormal={kde(fg)}\nForegroundInactive={kde(m)}\n"
                   f"ForegroundActive={kde(CYAN)}\nForegroundLink={kde(SKY)}\nForegroundVisited={kde(mix(SKY, SLATE, 0.4))}\n"
                   f"ForegroundNegative=240,96,88\nForegroundNeutral={kde(AMBER)}\nForegroundPositive=88,208,140\n"
                   f"DecorationFocus={kde(CYAN)}\nDecorationHover={kde(SKY)}\n")
    return "\n".join(out)


# ------------------------------------------------------------ colour scheme
def color_scheme():
    def group(name, bg, alt, fg=TEXT_ON_LIGHT, inactive=TEXT_MUTED_ON_LIGHT):
        return (f"[Colors:{name}]\nBackgroundAlternate={kde(alt)}\nBackgroundNormal={kde(bg)}\n"
                f"DecorationFocus={kde(SELECTION)}\nDecorationHover={kde(SKY)}\n"
                f"ForegroundActive={kde(mix(SELECTION, CYAN, 0.3))}\nForegroundInactive={kde(inactive)}\n"
                f"ForegroundLink={kde(SELECTION)}\nForegroundNegative=196,46,40\nForegroundNeutral=184,110,0\n"
                f"ForegroundNormal={kde(fg)}\nForegroundPositive=30,140,80\nForegroundVisited={kde(mix(SELECTION, SLATE, 0.5))}\n")
    parts = [
        "# Fortizan Aero — application colour scheme (generated by tools/gen-theme.py)\n",
        "[ColorEffects:Disabled]\nColor=56,56,56\nColorAmount=0\nColorEffect=0\nContrastAmount=0.65\n"
        "ContrastEffect=1\nIntensityAmount=0.1\nIntensityEffect=2\n",
        "[ColorEffects:Inactive]\nChangeSelectionColor=true\nColor=112,111,110\nColorAmount=0.025\nColorEffect=2\n"
        "ContrastAmount=0.1\nContrastEffect=2\nEnable=false\nIntensityAmount=0\nIntensityEffect=0\n",
        group("Button", BUTTON_BG, mix(BUTTON_BG, SKY, 0.15)),
        group("Complementary", NAVY, NAVY_SOFT, TEXT_ON_GLASS, TEXT_MUTED_ON_GLASS),
        group("Header", HEADER_BG, mix(HEADER_BG, WHITE, 0.4)),
        "[Colors:Header][Inactive]\n" + group("x", mix(HEADER_BG, WINDOW_BG, 0.6), WINDOW_BG).split("\n", 1)[1],
        group("Selection", SELECTION, mix(SELECTION, NAVY, 0.2), WHITE, (200, 220, 245)),
        group("Tooltip", NAVY_SOFT, NAVY, TEXT_ON_GLASS, TEXT_MUTED_ON_GLASS),
        group("View", VIEW_BG, (244, 248, 253)),
        group("Window", WINDOW_BG, mix(WINDOW_BG, SKY, 0.08)),
        "[General]\nColorScheme=FortizanAero\nName=Fortizan Aero\nshadeSortColumn=true\n",
        "[KDE]\ncontrast=4\n",
        f"[WM]\nactiveBackground={kde(mix(GLASS_CLEAR, GLASS_ICE, 0.5))}\nactiveBlend={kde(CYAN)}\n"
        f"activeForeground={kde(TITLE_TEXT)}\n"
        f"inactiveBackground={kde(mix(GLASS_ICE, SLATE, 0.25))}\ninactiveBlend={kde(SLATE)}\n"
        f"inactiveForeground={kde(TITLE_TEXT_INACTIVE)}\n",
    ]
    path = os.path.join(OV, "color-schemes", "FortizanAero.colors")
    write(path, "\n".join(parts))
    return path


# ------------------------------------------------------- window decoration
TITLE_H = 28
EDGE = 6        # Longhorn glass borders were noticeably thick
PAD = 14      # shadow padding painted into the decoration tiles


def deco_style(active, opaque):
    """Flat transparent title bars (owner direction): one even tint, no
    gradient, no reflection, no glow. A 1px hairline keeps windows apart."""
    a = 1.0 if opaque else (ALPHA_TITLE_ACTIVE if active else ALPHA_TITLE_INACTIVE)
    if active:
        c = GLASS_CLEAR if not opaque else mix(GLASS_CLEAR, GLASS_ICE, 0.5)
        return FrameStyle(radius=8, top_h=TITLE_H, edge=EDGE, inner=32,
                          stops=[(0.0, c, a), (1.0, c, a)], border=(GLASS_EDGE, 0.40))
    c = mix(GLASS_CLEAR, SLATE, 0.22) if not opaque else mix(GLASS_ICE, SLATE, 0.25)
    return FrameStyle(radius=8, top_h=TITLE_H, edge=EDGE, inner=32,
                      stops=[(0.0, c, a), (1.0, c, a)], border=(GLASS_EDGE, 0.25))


def build_aurorae():
    base = os.path.join(OV, "aurorae", "themes", "FortizanAero")
    if os.path.isdir(base):
        shutil.rmtree(base)
    doc = SvgDoc()
    x = 2
    for prefix, active, opaque in (("decoration", True, False), ("decoration-inactive", False, False),
                                   ("decoration-opaque", True, True), ("decoration-opaque-inactive", False, True)):
        w, h = add_frame(doc, prefix, deco_style(active, opaque), x, 2, pad=PAD, pad_shadow=0.30 if active else 0.18,
                         mask_prefix="mask" if prefix == "decoration" else None)
        x += w + 12
    # Maximised windows: only the "center" element is used, as the whole title bar.
    for prefix, active, opaque in (("decoration-maximized", True, False), ("decoration-maximized-inactive", False, False),
                                   ("decoration-maximized-opaque", True, True),
                                   ("decoration-maximized-opaque-inactive", False, True)):
        st = deco_style(active, opaque)
        band = [(o / 0.42, c, a) for o, c, a in st.stops if o <= 0.42]
        g = doc.linear(band)
        out = f'<rect x="{x}" y="2" width="32" height="{TITLE_H}" fill="url(#{g})"/>'
        doc.group(prefix + "-center", x, 2, 32, TITLE_H, out)
        x += 40
    deco = os.path.join(base, "decoration.svg")
    write(deco, doc.render())
    raster(deco, os.path.join(PREV, "aurorae", "decoration.png"))

    for name in ("close", "minimize", "maximize", "restore"):
        p = os.path.join(base, name + ".svg")
        write(p, button_svg(name))
        raster(p, os.path.join(PREV, "aurorae", name + ".png"), w=None)

    write(os.path.join(base, "FortizanAerorc"),
          "# Fortizan Aero window decoration (generated by tools/gen-theme.py)\n"
          "[General]\n"
          "TitleAlignment=Left\nTitleVerticalAlignment=Center\nAnimation=120\n"
          f"ActiveTextColor={kde(TITLE_TEXT)},255\nInactiveTextColor={kde(TITLE_TEXT_INACTIVE)},255\n"
          f"UseTextShadow=true\nActiveTextShadowColor={kde(TITLE_GLOW)},230\nInactiveTextShadowColor={kde(TITLE_GLOW)},150\n"
          "TextShadowOffsetX=0\nTextShadowOffsetY=0\n"
          "HaloActive=false\nHaloInactive=false\n"
          "LeftButtons=M\nRightButtons=IAX\n"
          "Shadow=true\n\n"
          "[Layout]\n"
          f"BorderLeft={EDGE}\nBorderRight={EDGE}\nBorderBottom={EDGE}\nBorderTop=0\n"
          "TitleEdgeTop=4\nTitleEdgeBottom=4\nTitleEdgeLeft=6\nTitleEdgeRight=6\n"
          "TitleEdgeTopMaximized=0\nTitleEdgeBottomMaximized=0\nTitleEdgeLeftMaximized=0\nTitleEdgeRightMaximized=0\n"
          f"TitleBorderLeft=6\nTitleBorderRight=6\nTitleHeight={TITLE_H - 8}\n"
          "ButtonWidth=28\nButtonHeight=20\nButtonWidthClose=44\nButtonSpacing=2\nButtonMarginTop=0\n"
          "ExplicitButtonSpacer=8\n"
          f"PaddingTop={PAD}\nPaddingBottom={PAD}\nPaddingLeft={PAD}\nPaddingRight={PAD}\n")
    write(os.path.join(base, "metadata.desktop"),
          "[Desktop Entry]\nName=Fortizan Aero\nComment=Frosted glass window decoration inspired by Longhorn 4074\n"
          "X-KDE-PluginInfo-Name=FortizanAero\nX-KDE-PluginInfo-Author=FortizanOS Project\n"
          f"X-KDE-PluginInfo-Version={VERSION}\nX-KDE-PluginInfo-License=CC-BY-SA-4.0\n"
          "X-KDE-PluginInfo-Website=\nX-KDE-PluginInfo-Email=\n")
    return base


def button_svg(kind):
    """Flat transparent caption buttons. Minimise/maximise: no background
    until hovered (flat dark tint). Close: flat translucent red."""
    W, H = (44 if kind == "close" else 28), 20
    doc = SvgDoc()
    close = kind == "close"
    #            state                  (fill rgb,                     fill alpha, glyph alpha, white glyph?)
    states = {
        "active":               (CLOSE_RED if close else GLASS_EDGE, 0.85 if close else 0.0, 1.0, close),
        "hover":                (mix(CLOSE_RED, WHITE, 0.15) if close else GLASS_EDGE, 1.0 if close else 0.14, 1.0, close),
        "pressed":              (mix(CLOSE_RED, BLACK_, 0.25) if close else GLASS_EDGE, 1.0 if close else 0.26, 1.0, close),
        "inactive":             (mix(CLOSE_RED, SLATE, 0.55) if close else GLASS_EDGE, 0.45 if close else 0.0, 0.65, close),
        "hover-inactive":       (CLOSE_RED if close else GLASS_EDGE, 0.85 if close else 0.12, 1.0, close),
        "pressed-inactive":     (mix(CLOSE_RED, BLACK_, 0.25) if close else GLASS_EDGE, 1.0 if close else 0.24, 1.0, close),
        "deactivated":          (SLATE, 0.0, 0.30, False),
        "deactivated-inactive": (SLATE, 0.0, 0.25, False),
    }
    x = 2
    for state, (rgb, fa, ga, white) in states.items():
        content = (f'<rect x="{x}" y="2" width="{W}" height="{H}" rx="3" fill="{hexc(rgb)}" '
                   f'fill-opacity="{fa:.2f}"/>') if fa > 0 else ""
        content += glyph(kind, x + W / 2, 2 + H / 2, ga, dark=not white)
        doc.group(f"{state}-center", x, 2, W, H, content)
        x += W + 6
    return doc.render()


BLACK_ = (0, 0, 0)


def glyph(kind, cx, cy, a, dark=False):
    fg = hexc(TITLE_TEXT) if dark else "#ffffff"
    s = f'stroke="{fg}" stroke-opacity="{a:.2f}" stroke-width="1.6" fill="none" stroke-linecap="round" stroke-linejoin="round"'
    if kind == "close":
        d = f"M{cx - 4},{cy - 4} L{cx + 4},{cy + 4} M{cx + 4},{cy - 4} L{cx - 4},{cy + 4}"
    elif kind == "minimize":
        d = f"M{cx - 4.5},{cy + 3.5} H{cx + 4.5}"
    elif kind == "maximize":
        d = f"M{cx - 4.5},{cy - 3.5} H{cx + 4.5} V{cy + 3.5} H{cx - 4.5} Z M{cx - 4.5},{cy - 2} H{cx + 4.5}"
    else:  # restore: two overlapping windows
        d = (f"M{cx - 4.5},{cy - 1} H{cx + 2} V{cy + 4} H{cx - 4.5} Z "
             f"M{cx - 2},{cy - 1} V{cy - 4} H{cx + 4.5} V{cy + 1.5} H{cx + 2}")
    return f'<path d="{d}" {s}/>'  # flat: no halo/shadow


# ------------------------------------------------------------------ wallpaper
def wallpaper_svg(w, h):
    """Original abstract wallpaper: deep blue space with flowing light ribbons and glass panes."""
    def ribbon(y0, amp, col, op, width, blur, phase):
        pts = []
        steps = 8
        for i in range(steps + 1):
            x = w * i / steps
            import math
            y = y0 + amp * math.sin(i / steps * math.pi * 1.6 + phase)
            pts.append((x, y))
        d = f"M{-50},{pts[0][1]:.1f} " + " ".join(
            f"S{(pts[i][0] + pts[i - 1][0]) / 2:.1f},{pts[i][1]:.1f} {pts[i][0]:.1f},{pts[i][1]:.1f}"
            for i in range(1, len(pts))) + f" L{w + 50},{pts[-1][1]:.1f}"
        return (f'<path d="{d}" stroke="{hexc(col)}" stroke-opacity="{op}" stroke-width="{width}" '
                f'fill="none" stroke-linecap="round" filter="url(#b{blur})"/>')
    k = h / 1080.0
    blurs = "".join(f'<filter id="b{b}" x="-20%" y="-50%" width="140%" height="200%">'
                    f'<feGaussianBlur stdDeviation="{b * k:.1f}"/></filter>' for b in (2, 8, 24, 60))
    panes = ""
    for i, (px, py, pw, ph, rot, op) in enumerate([
            (0.58, 0.16, 0.30, 0.42, -12, 0.07), (0.70, 0.30, 0.22, 0.34, -12, 0.06),
            (0.08, 0.56, 0.20, 0.26, 10, 0.05)]):
        panes += (f'<rect x="{px * w:.0f}" y="{py * h:.0f}" width="{pw * w:.0f}" height="{ph * h:.0f}" rx="{18 * k:.0f}" '
                  f'transform="rotate({rot} {px * w:.0f} {py * h:.0f})" fill="url(#pane)" fill-opacity="{op}" '
                  f'stroke="#bfe6ff" stroke-opacity="{op * 2.2:.2f}" stroke-width="{1.5 * k:.1f}"/>')
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="{w}" height="{h}" viewBox="0 0 {w} {h}">
<defs>
 <radialGradient id="sky" cx="0.72" cy="0.30" r="0.95">
  <stop offset="0" stop-color="{hexc(mix(AERO_BLUE, SKY, 0.15))}"/>
  <stop offset="0.35" stop-color="{hexc(mix(AERO_BLUE, NAVY, 0.55))}"/>
  <stop offset="0.75" stop-color="{hexc(NAVY_DEEP)}"/>
  <stop offset="1" stop-color="#030a16"/>
 </radialGradient>
 <radialGradient id="glow" cx="0.70" cy="0.38" r="0.35">
  <stop offset="0" stop-color="{hexc(CYAN)}" stop-opacity="0.35"/>
  <stop offset="1" stop-color="{hexc(CYAN)}" stop-opacity="0"/>
 </radialGradient>
 <linearGradient id="pane" x1="0" y1="0" x2="1" y2="1">
  <stop offset="0" stop-color="#ffffff"/><stop offset="1" stop-color="{hexc(SKY)}"/>
 </linearGradient>
 {blurs}
</defs>
<rect width="{w}" height="{h}" fill="url(#sky)"/>
<rect width="{w}" height="{h}" fill="url(#glow)"/>
{ribbon(h * 0.62, h * 0.10, CYAN, 0.30, 90 * k, 60, 0.3)}
{ribbon(h * 0.60, h * 0.11, SKY, 0.55, 14 * k, 8, 0.25)}
{ribbon(h * 0.66, h * 0.09, CYAN, 0.85, 3 * k, 2, 0.45)}
{ribbon(h * 0.71, h * 0.08, mix(SKY, WHITE, 0.4), 0.40, 2 * k, 2, 0.6)}
{ribbon(h * 0.52, h * 0.13, AERO_BLUE, 0.50, 40 * k, 24, 0.05)}
{panes}
</svg>'''


def build_wallpaper():
    base = os.path.join(OV, "wallpapers", "FortizanAero")
    if not RASTER:          # cannot re-render images: keep the committed ones
        return base
    if os.path.isdir(base):
        shutil.rmtree(base)
    meta = {"KPlugin": {"Authors": [{"Name": "FortizanOS Project"}], "Id": "FortizanAero",
                        "License": "CC-BY-SA-4.0", "Name": "Fortizan Aero"}}
    write(os.path.join(base, "metadata.json"), json.dumps(meta, indent=4) + "\n")
    src_dir = os.path.join(ROOT, "build", "wallpaper-src")
    for (w, h) in ((1920, 1080), (2560, 1440), (3840, 2160), (1920, 1200)):
        svg = os.path.join(src_dir, f"{w}x{h}.svg")
        write(svg, wallpaper_svg(w, h))
        png = os.path.join(src_dir, f"{w}x{h}.png")
        raster(svg, png)
        if RASTER:
            jpg = os.path.join(base, "contents", "images", f"{w}x{h}.jpg")
            os.makedirs(os.path.dirname(jpg), exist_ok=True)
            subprocess.run(["convert", png, "-quality", "90", jpg], check=True)
    if RASTER:
        subprocess.run(["convert", os.path.join(src_dir, "1920x1080.png"), "-resize", "400x225",
                        os.path.join(base, "contents", "screenshot.jpg")], check=True)
    return base


# ---------------------------------------------------------------------- icons
def orb(size_scale=1.0):
    """FortizanOS logo: a glass orb with a cyan aurora arc (original design)."""
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
<defs>
 <radialGradient id="o" cx="0.42" cy="0.35" r="0.7">
  <stop offset="0" stop-color="{hexc(mix(SKY, WHITE, 0.3))}"/>
  <stop offset="0.45" stop-color="{hexc(AERO_BLUE)}"/>
  <stop offset="1" stop-color="{hexc(NAVY_DEEP)}"/>
 </radialGradient>
 <linearGradient id="s" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="#ffffff" stop-opacity="0.75"/>
  <stop offset="1" stop-color="#ffffff" stop-opacity="0"/>
 </linearGradient>
 <linearGradient id="a" x1="0" y1="0" x2="1" y2="0">
  <stop offset="0" stop-color="{hexc(CYAN)}" stop-opacity="0"/>
  <stop offset="0.5" stop-color="{hexc(mix(CYAN, WHITE, 0.3))}"/>
  <stop offset="1" stop-color="{hexc(CYAN)}" stop-opacity="0.2"/>
 </linearGradient>
</defs>
<circle cx="32" cy="33" r="29" fill="#000" fill-opacity="0.25"/>
<circle cx="32" cy="32" r="28" fill="url(#o)" stroke="{hexc(NAVY_DEEP)}" stroke-width="1.5"/>
<path d="M9,40 C20,24 40,22 56,30" stroke="url(#a)" stroke-width="5" fill="none" stroke-linecap="round"/>
<path d="M12,46 C24,34 40,33 53,38" stroke="url(#a)" stroke-width="2.4" fill="none" stroke-linecap="round" opacity="0.8"/>
<ellipse cx="30" cy="19" rx="19" ry="11" fill="url(#s)"/>
<circle cx="32" cy="32" r="27.2" fill="none" stroke="#ffffff" stroke-opacity="0.25"/>
</svg>
'''


def folder_icon(emblem):
    """Glossy glass folder with a simple white emblem."""
    em = {
        "": "",
        "documents": '<path d="M27 30h14M27 35h14M27 40h10" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>',
        "download": '<path d="M34 27v14M28 36l6 6 6-6" stroke="#fff" stroke-width="2.6" fill="none" stroke-linecap="round" stroke-linejoin="round"/>',
        "music": '<path d="M30 42a3.5 3 0 1 1-1-6V28l12-2v13" stroke="#fff" stroke-width="2.4" fill="none" stroke-linecap="round"/><ellipse cx="38" cy="39.5" rx="3.5" ry="3" fill="#fff"/><ellipse cx="27" cy="42" rx="3.5" ry="3" fill="#fff"/>',
        "pictures": '<path d="M25 42l6-8 5 6 3-3 5 5z" fill="#fff"/><circle cx="40" cy="30" r="2.6" fill="#fff"/>',
        "videos": '<path d="M29 28v14l12-7z" fill="#fff"/>',
        "home": '<path d="M24 35l10-9 10 9M27 33v9h14v-9" stroke="#fff" stroke-width="2.6" fill="none" stroke-linejoin="round" stroke-linecap="round"/>',
        "desktop": '<rect x="25" y="28" width="18" height="11" rx="1.5" stroke="#fff" stroke-width="2.4" fill="none"/><path d="M30 43h8" stroke="#fff" stroke-width="2.4" stroke-linecap="round"/>',
    }[emblem]
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
<defs>
 <linearGradient id="back" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="{hexc(mix(AERO_BLUE, NAVY, 0.2))}"/><stop offset="1" stop-color="{hexc(NAVY)}"/>
 </linearGradient>
 <linearGradient id="front" x1="0" y1="0" x2="0" y2="1">
  <stop offset="0" stop-color="{hexc(mix(SKY, WHITE, 0.25))}"/>
  <stop offset="0.48" stop-color="{hexc(mix(SKY, AERO_BLUE, 0.35))}"/>
  <stop offset="0.52" stop-color="{hexc(mix(AERO_BLUE, SKY, 0.25))}"/>
  <stop offset="1" stop-color="{hexc(AERO_BLUE)}"/>
 </linearGradient>
</defs>
<path d="M6 14a3 3 0 0 1 3-3h15l5 5h26a3 3 0 0 1 3 3v31H6z" fill="url(#back)"/>
<rect x="6" y="20" width="52" height="34" rx="3" fill="#000" fill-opacity="0.18" transform="translate(0,1.5)"/>
<rect x="6" y="20" width="52" height="34" rx="3" fill="url(#front)" stroke="{hexc(NAVY)}" stroke-opacity="0.6"/>
<path d="M9 22h46" stroke="#fff" stroke-opacity="0.65" stroke-linecap="round"/>
<g opacity="0.95">{em}</g>
</svg>
'''


def trash_icon(full):
    papers = ('<path d="M24 16l6-4 5 5M33 14l7-3 4 6" stroke="#fff" stroke-width="2" fill="none"/>'
              if full else "")
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
<defs><linearGradient id="g" x1="0" y1="0" x2="1" y2="0">
 <stop offset="0" stop-color="{hexc(mix(SKY, NAVY, 0.4))}" stop-opacity="0.85"/>
 <stop offset="0.35" stop-color="{hexc(mix(SKY, WHITE, 0.4))}" stop-opacity="0.9"/>
 <stop offset="1" stop-color="{hexc(AERO_BLUE)}" stop-opacity="0.9"/></linearGradient></defs>
{papers}
<path d="M17 20h30l-3 35a3 3 0 0 1-3 3H23a3 3 0 0 1-3-3z" fill="url(#g)" stroke="{hexc(NAVY)}" stroke-opacity="0.7"/>
<path d="M26 26v26M32 26v26M38 26v26" stroke="#fff" stroke-opacity="0.55" stroke-width="2"/>
<rect x="14" y="16" width="36" height="5" rx="2" fill="{hexc(mix(SKY, WHITE, 0.3))}" stroke="{hexc(NAVY)}" stroke-opacity="0.7"/>
</svg>
'''


def computer_icon():
    return f'''<svg xmlns="http://www.w3.org/2000/svg" width="64" height="64" viewBox="0 0 64 64">
<defs><linearGradient id="sc" x1="0" y1="0" x2="1" y2="1">
 <stop offset="0" stop-color="{hexc(mix(SKY, WHITE, 0.2))}"/><stop offset="0.5" stop-color="{hexc(AERO_BLUE)}"/>
 <stop offset="1" stop-color="{hexc(NAVY_DEEP)}"/></linearGradient></defs>
<rect x="6" y="9" width="52" height="36" rx="3" fill="{hexc(NAVY_DEEP)}"/>
<rect x="9" y="12" width="46" height="30" rx="1.5" fill="url(#sc)"/>
<path d="M9 12h46l-46 18z" fill="#fff" fill-opacity="0.18"/>
<path d="M24 45h16l3 8H21z" fill="{hexc(SLATE)}"/><rect x="16" y="52" width="32" height="4" rx="2" fill="{hexc(mix(SLATE, WHITE, 0.3))}"/>
</svg>
'''


def build_icons():
    base = os.path.join(OV, "icons", "FortizanAero")
    if os.path.isdir(base):
        shutil.rmtree(base)
    write(os.path.join(base, "index.theme"),
          "[Icon Theme]\nName=Fortizan Aero\nComment=FortizanOS glossy places icons on top of Breeze\n"
          "Inherits=breeze,hicolor\nExample=folder\nDirectories=scalable/places,scalable/apps,scalable/devices\n\n"
          "[scalable/places]\nSize=64\nMinSize=16\nMaxSize=512\nType=Scalable\nContext=Places\n\n"
          "[scalable/apps]\nSize=64\nMinSize=16\nMaxSize=512\nType=Scalable\nContext=Applications\n\n"
          "[scalable/devices]\nSize=64\nMinSize=16\nMaxSize=512\nType=Scalable\nContext=Devices\n")
    places = {
        "folder": folder_icon(""), "folder-documents": folder_icon("documents"),
        "folder-download": folder_icon("download"), "folder-downloads": folder_icon("download"),
        "folder-music": folder_icon("music"), "folder-pictures": folder_icon("pictures"),
        "folder-images": folder_icon("pictures"), "folder-videos": folder_icon("videos"),
        "user-home": folder_icon("home"), "folder-home": folder_icon("home"),
        "user-desktop": folder_icon("desktop"), "folder-desktop": folder_icon("desktop"),
        "user-trash": trash_icon(False), "user-trash-full": trash_icon(True),
        "start-here": orb(), "start-here-kde": orb(), "start-here-kde-plasma": orb(),
        "distributor-logo": orb(),
    }
    for name, svg in places.items():
        write(os.path.join(base, "scalable", "places", name + ".svg"), svg)
    write(os.path.join(base, "scalable", "devices", "computer.svg"), computer_icon())
    write(os.path.join(base, "scalable", "apps", "fortizanos-logo.svg"), orb())
    # The logo also goes into hicolor so it works with ANY icon theme.
    write(os.path.join(OV, "icons", "hicolor", "scalable", "apps", "fortizanos-logo.svg"), orb())
    write(os.path.join(OV, "pixmaps", "fortizanos-logo.svg"), orb())
    if RASTER:
        sheet = os.path.join(PREV, "icons")
        os.makedirs(sheet, exist_ok=True)
        for name in ("folder", "folder-documents", "folder-download", "folder-music", "folder-pictures",
                     "folder-videos", "user-home", "user-desktop", "user-trash", "user-trash-full", "start-here"):
            raster(os.path.join(base, "scalable", "places", name + ".svg"), os.path.join(sheet, name + ".png"), w=64)
        raster(os.path.join(base, "scalable", "devices", "computer.svg"), os.path.join(sheet, "computer.png"), w=64)
    return base


# ----------------------------------------------- global theme + system defaults
LNF_ID = "org.fortizanos.aero.desktop"
AURORAE_ID = "__aurorae__svg__FortizanAero"
ANIM_FACTOR = "0.7071"
UI_FONT = "Selawik"         # bundled by scripts/fetch-fonts.sh (OFL); "Segoe UI" requests also map to it    # KDE's "slightly faster" step; 0 disables animations


def build_global_theme():
    base = os.path.join(OV, "plasma", "look-and-feel", LNF_ID)
    if os.path.isdir(base):
        for entry in os.listdir(base):          # keep committed previews in --no-raster mode
            if RASTER or entry != "contents":
                shutil.rmtree(os.path.join(base, entry)) if os.path.isdir(os.path.join(base, entry)) else os.remove(os.path.join(base, entry))
        if not RASTER and os.path.isdir(os.path.join(base, "contents")):
            for entry in os.listdir(os.path.join(base, "contents")):
                if entry != "previews":
                    pth = os.path.join(base, "contents", entry)
                    shutil.rmtree(pth) if os.path.isdir(pth) else os.remove(pth)
    meta = {
        "KPackageStructure": "Plasma/LookAndFeel",
        "KPlugin": {
            "Authors": [{"Name": "FortizanOS Project"}],
            "Description": "FortizanOS desktop: Longhorn 4074-inspired frosted glass",
            "Id": LNF_ID, "License": "CC-BY-SA-4.0", "Name": "Fortizan Aero", "Version": VERSION,
        },
        "X-Plasma-APIVersion": "2",
    }
    write(os.path.join(base, "metadata.json"), json.dumps(meta, indent=4) + "\n")
    write(os.path.join(base, "contents", "defaults"),
          "[kdeglobals][KDE]\nwidgetStyle=Breeze\n\n"
          "[kdeglobals][General]\nColorScheme=FortizanAero\n\n"
          "[kdeglobals][Icons]\nTheme=FortizanAero\n\n"
          "[plasmarc][Theme]\nname=fortizan-aero\n\n"
          "[kcminputrc][Mouse]\ncursorTheme=breeze_cursors\n\n"
          f"[kwinrc][org.kde.kdecoration2]\nlibrary=org.kde.kwin.aurorae\ntheme={AURORAE_ID}\n\n"
          "[kwinrc][WindowSwitcher]\nLayoutName=org.kde.breeze.desktop\n\n"
          "[kwinrc][DesktopSwitcher]\nLayoutName=org.kde.breeze.desktop\n\n"
          "[ksplashrc][KSplash]\nEngine=none\nTheme=None\n")
    write(os.path.join(base, "contents", "layouts", "org.kde.plasma.desktop-layout.js"), LAYOUT_JS)
    if RASTER:
        os.makedirs(os.path.join(base, "contents", "previews"), exist_ok=True)
        mock = os.path.join(ROOT, "docs", "images", "m2-mockup.png")
        if os.path.exists(mock):
            subprocess.run(["convert", mock, "-resize", "640x360", os.path.join(base, "contents", "previews", "preview.png")], check=True)
            subprocess.run(["convert", mock, "-resize", "1280x720", os.path.join(base, "contents", "previews", "fullscreenpreview.jpg")], check=True)
    return base


LAYOUT_JS = r"""// FortizanOS default desktop layout (Plasma scripting API).
// Runs once, the first time a user logs in with the Fortizan Aero global theme.
// Longhorn-style taskbar: full-width, bottom, task buttons with labels.

var desktops = desktopsForActivity(currentActivity());
for (var i = 0; i < desktops.length; i++) {
    var desk = desktops[i];
    desk.wallpaperPlugin = "org.kde.image";
    desk.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desk.writeConfig("Image", "file:///usr/share/wallpapers/FortizanAero/");
}

var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.floor(gridUnit * 2.5 / 2);
panel.floating = false;              // edge-to-edge taskbar, no floating gap
panel.hiding = "none";

var launcher = panel.addWidget("org.kde.plasma.kickoff");   // stock launcher, themed (custom Start menu = Milestone 3)
launcher.currentConfigGroup = ["General"];
launcher.writeConfig("icon", "fortizanos-logo");
launcher.writeConfig("menuLabel", "Start");                 // orb + label, Longhorn-style start button

var tasks = panel.addWidget("org.kde.plasma.taskmanager");  // buttons WITH labels, like Longhorn
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", ["preferred://filemanager", "preferred://browser"]);
tasks.writeConfig("groupingStrategy", 0);                   // one button per window
tasks.writeConfig("maxStripes", 1);

panel.addWidget("org.kde.plasma.marginsseparator");
panel.addWidget("org.kde.plasma.systemtray");

var clock = panel.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", true);
clock.writeConfig("dateDisplayFormat", "BelowTime");

panel.addWidget("org.kde.plasma.showdesktop");              // corner "show desktop" strip
"""


def build_system_defaults():
    """/etc/xdg files: make Fortizan Aero the default for every new user.

    The full colour groups are copied into kdeglobals because many KDE apps
    read colours from kdeglobals directly rather than from the scheme name.
    """
    etc = os.path.join(ROOT, "overlay", "etc", "xdg")
    scheme = open(os.path.join(OV, "color-schemes", "FortizanAero.colors"), encoding="utf-8").read()
    colour_groups = "\n".join(block for block in scheme.split("\n\n")
                              if block.startswith(("[Colors:", "[ColorEffects:", "[WM]")))
    write(os.path.join(etc, "kdeglobals"),
          "# FortizanOS system defaults (generated by tools/gen-theme.py).\n"
          "# Users' own settings in ~/.config/kdeglobals always take priority.\n\n"
          f"[KDE]\nLookAndFeelPackage={LNF_ID}\nwidgetStyle=Breeze\nAnimationDurationFactor={ANIM_FACTOR}\n\n"
          "[General]\nColorScheme=FortizanAero\n"
          # Default UI font: Selawik (Microsoft's open-source Segoe UI replacement,
          # SIL OFL 1.1), bundled in /usr/share/fonts/selawik.
          f"font={UI_FONT},10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1\n"
          f"menuFont={UI_FONT},10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1\n"
          f"toolBarFont={UI_FONT},10,-1,5,400,0,0,0,0,0,0,0,0,0,0,1\n"
          f"smallestReadableFont={UI_FONT},8,-1,5,400,0,0,0,0,0,0,0,0,0,0,1\n\n"
          "[Icons]\nTheme=FortizanAero\n\n"
          # semi-bold window titles in the same family
          + colour_groups.replace("[WM]\n", f"[WM]\nactiveFont={UI_FONT},10,-1,5,600,0,0,0,0,0,0,0,0,0,0,1\n", 1)
          + "\n")
    write(os.path.join(etc, "plasmarc"), "[Theme]\nname=fortizan-aero\n")
    write(os.path.join(etc, "kwinrc"),
          "# FortizanOS window manager defaults. Change with `fortizan-effects` or System Settings.\n"
          f"[org.kde.kdecoration2]\nlibrary=org.kde.kwin.aurorae\ntheme={AURORAE_ID}\n"
          "ButtonsOnLeft=M\nButtonsOnRight=IAX\nBorderSize=Normal\n\n"
          "[Plugins]\nblurEnabled=true\ncontrastEnabled=true\n\n"
          f"[Effect-blur]\nBlurStrength={BLUR_STRENGTH}\nNoiseStrength={BLUR_NOISE}\n")
    write(os.path.join(etc, "breezerc"),
          f"[Style]\n# Lightly frosted context menus (100 = solid)\nMenuOpacity={MENU_OPACITY_PERCENT}\n")
    # File search: index file NAMES only (fast, tiny), not file contents, which
    # keeps a background indexer busy for a long time after first login.
    write(os.path.join(etc, "baloofilerc"),
          "[General]\n# FortizanOS: file-name search only. Turn on content indexing in\n"
          "# System Settings > Search > File Search if you want it.\nonly basic indexing=true\n")
    write(os.path.join(etc, "ksplashrc"),
          "[KSplash]\n# No splash screen: faster login, no third-party logos\nEngine=none\nTheme=None\n")
    return etc


def main():
    print("Plasma style  ->", os.path.relpath(build_plasma_style(), ROOT))
    print("Colour scheme ->", os.path.relpath(color_scheme(), ROOT))
    print("Decoration    ->", os.path.relpath(build_aurorae(), ROOT))
    print("Icons         ->", os.path.relpath(build_icons(), ROOT))
    print("Wallpaper     ->", os.path.relpath(build_wallpaper(), ROOT))
    print("Global theme  ->", os.path.relpath(build_global_theme(), ROOT))
    print("Defaults      ->", os.path.relpath(build_system_defaults(), ROOT))
    if RASTER:
        print("Previews      ->", os.path.relpath(PREV, ROOT))


if __name__ == "__main__":
    main()
