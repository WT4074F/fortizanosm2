#!/usr/bin/env python3
"""Validate the generated theme files. Exit code = number of problems.

Checks:
 * every SVG parses as XML
 * every 9-slice element renders at exactly its declared tile size
   (catches bounding-box bugs that make KDE draw frames wrongly)
 * every frame prefix has all 9 parts; masks complete
 * required files for each theme format exist
Requires rsvg-convert + Pillow for the render check (skipped if missing).
"""
import glob
import io
import os
import re
import shutil
import subprocess
import sys
import xml.etree.ElementTree as ET

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SHARE = os.path.join(ROOT, "overlay", "usr", "share")
PARTS = ["topleft", "top", "topright", "left", "center", "right", "bottomleft", "bottom", "bottomright"]
problems = 0


def bad(msg):
    global problems
    problems += 1
    print("  [FAIL]", msg)


def check_svg(path, render):
    try:
        tree = ET.parse(path)
    except ET.ParseError as e:
        bad(f"{path}: XML error {e}")
        return
    ns = "{http://www.w3.org/2000/svg}"
    groups = {}
    for g in tree.iter(ns + "g"):
        gid = g.get("id")
        rect = g.find(ns + "rect")
        if gid and rect is not None:
            groups[gid] = (float(rect.get("width")), float(rect.get("height")))
    # completeness per prefix
    prefixes = set()
    for gid in groups:
        for p in PARTS:
            if gid == p:
                prefixes.add("")
            elif gid.endswith("-" + p):
                prefixes.add(gid[: -len(p) - 1])
    for pre in prefixes:
        if pre.startswith("shadow") or pre.endswith("shadow"):
            continue
        missing = [p for p in PARTS if (f"{pre}-{p}" if pre else p) not in groups]
        if missing and not pre.startswith("decoration-maximized") and pre not in ("active", "hover", "pressed",
                                                                                  "inactive", "hover-inactive",
                                                                                  "pressed-inactive", "deactivated",
                                                                                  "deactivated-inactive"):
            bad(f"{os.path.relpath(path, ROOT)}: prefix '{pre}' missing {missing}")
    if not render:
        return
    from PIL import Image
    for gid, (w, h) in groups.items():
        if gid.startswith("hint-"):
            continue
        png = subprocess.run(["rsvg-convert", "-i", gid, path], capture_output=True).stdout
        if not png:
            bad(f"{os.path.relpath(path, ROOT)}#{gid}: did not render")
            continue
        size = Image.open(io.BytesIO(png)).size
        if abs(size[0] - w) > 1 or abs(size[1] - h) > 1:
            bad(f"{os.path.relpath(path, ROOT)}#{gid}: renders {size}, expected {(int(w), int(h))}")


def require(paths):
    for p in paths:
        if not os.path.exists(os.path.join(SHARE, p)):
            bad(f"missing {p}")


def main():
    render = shutil.which("rsvg-convert") is not None
    try:
        import PIL  # noqa: F401
    except ImportError:
        render = False
    print("== Theme check", "(with render check)" if render else "(structure only)")
    require([
        "plasma/desktoptheme/fortizan-aero/metadata.json",
        "plasma/desktoptheme/fortizan-aero/plasmarc",
        "plasma/desktoptheme/fortizan-aero/colors",
        "plasma/desktoptheme/fortizan-aero/widgets/panel-background.svg",
        "plasma/desktoptheme/fortizan-aero/translucent/widgets/panel-background.svg",
        "plasma/desktoptheme/fortizan-aero/dialogs/background.svg",
        "plasma/desktoptheme/fortizan-aero/widgets/tasks.svg",
        "aurorae/themes/FortizanAero/decoration.svg",
        "aurorae/themes/FortizanAero/FortizanAerorc",
        "aurorae/themes/FortizanAero/metadata.desktop",
        "aurorae/themes/FortizanAero/close.svg",
        "color-schemes/FortizanAero.colors",
        "icons/FortizanAero/index.theme",
        "wallpapers/FortizanAero/metadata.json",
        "plasma/look-and-feel/org.fortizanos.aero.desktop/metadata.json",
        "plasma/look-and-feel/org.fortizanos.aero.desktop/contents/defaults",
        "plasma/look-and-feel/org.fortizanos.aero.desktop/contents/layouts/org.kde.plasma.desktop-layout.js",
    ])
    if not glob.glob(os.path.join(SHARE, "wallpapers/FortizanAero/contents/images/*.jpg")):
        bad("wallpaper has no images")
    svgs = glob.glob(os.path.join(SHARE, "plasma/desktoptheme/fortizan-aero/**/*.svg"), recursive=True) + \
        glob.glob(os.path.join(SHARE, "aurorae/themes/FortizanAero/*.svg"))
    for s in sorted(svgs):
        check_svg(s, render)
    # Aurorae: every button needs an active-center element
    for b in ("close", "minimize", "maximize", "restore"):
        p = os.path.join(SHARE, "aurorae/themes/FortizanAero", b + ".svg")
        if os.path.exists(p) and 'id="active-center"' not in open(p).read():
            bad(f"{b}.svg lacks active-center")
    # Aurorae blur needs a mask
    deco = os.path.join(SHARE, "aurorae/themes/FortizanAero/decoration.svg")
    if os.path.exists(deco) and 'id="mask-center"' not in open(deco).read():
        bad("decoration.svg lacks mask (blur would be disabled)")
    # colour files must parse as INI-ish key=value with r,g,b triplets
    for cf in (os.path.join(SHARE, "color-schemes/FortizanAero.colors"),
               os.path.join(SHARE, "plasma/desktoptheme/fortizan-aero/colors")):
        if os.path.exists(cf):
            for n, line in enumerate(open(cf), 1):
                line = line.strip()
                if not line or line.startswith(("#", "[")):
                    continue
                k, _, v = line.partition("=")
                if not k or (re.fullmatch(r"\d+,\d+,\d+", v) is None and k.startswith(("Background", "Foreground", "Decoration"))):
                    bad(f"{os.path.relpath(cf, ROOT)}:{n}: bad colour line '{line}'")
    print("THEME CHECK OK" if problems == 0 else f"THEME CHECK FAILED ({problems})")
    sys.exit(min(problems, 100))


if __name__ == "__main__":
    main()
