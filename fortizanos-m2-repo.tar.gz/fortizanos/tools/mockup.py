#!/usr/bin/env python3
"""Render a mock-up of the Fortizan Aero desktop from the REAL theme files.

This is a design-review aid, not a screenshot: it stretches the generated
9-slice SVG pieces the same way KDE's FrameSvg does and imitates KWin's
blur with a Gaussian blur. Use it to judge colours, contrast and balance
before spending an hour on an ISO build.

Usage: python3 tools/mockup.py [--no-blur] [-o out.png]
Requires: rsvg-convert, Pillow.
"""
import io
import os
import subprocess
import sys
from functools import lru_cache

from PIL import Image, ImageDraw, ImageEnhance, ImageFilter, ImageFont

ROOT = os.path.abspath(os.path.join(os.path.dirname(__file__), ".."))
SHARE = os.path.join(ROOT, "overlay", "usr", "share")
PLASMA = os.path.join(SHARE, "plasma", "desktoptheme", "fortizan-aero")
AUR = os.path.join(SHARE, "aurorae", "themes", "FortizanAero")
ICONS = os.path.join(SHARE, "icons", "FortizanAero", "scalable")
BLUR = "--no-blur" not in sys.argv
OUT = sys.argv[sys.argv.index("-o") + 1] if "-o" in sys.argv else os.path.join(ROOT, "docs", "images", "m2-mockup.png")
W, H = 1600, 900


def font(size, bold=False):
    for p in (f"/usr/share/fonts/opentype/inter/Inter-{'SemiBold' if bold else 'Regular'}.otf",
              f"/usr/share/fonts/truetype/dejavu/DejaVuSans{'-Bold' if bold else ''}.ttf"):
        if os.path.exists(p):
            return ImageFont.truetype(p, size)
    return ImageFont.load_default()


@lru_cache(None)
def element(svg, eid):
    png = subprocess.run(["rsvg-convert", "-i", eid, svg], capture_output=True, check=True).stdout
    return Image.open(io.BytesIO(png)).convert("RGBA")


def icon(name, size, sub="places"):
    png = subprocess.run(["rsvg-convert", "-w", str(size), "-h", str(size),
                          os.path.join(ICONS, sub, name + ".svg")], capture_output=True, check=True).stdout
    return Image.open(io.BytesIO(png)).convert("RGBA")


def frame(svg, prefix, w, h, edges=("top", "bottom", "left", "right")):
    """Compose a FrameSvg of size w x h. `edges` lists which borders are enabled."""
    n = (lambda p: f"{prefix}-{p}") if prefix else (lambda p: p)
    tl, tr = element(svg, n("topleft")), element(svg, n("topright"))
    bl = element(svg, n("bottomleft"))
    lw = tl.width if "left" in edges else 0
    rw = tr.width if "right" in edges else 0
    th = tl.height if "top" in edges else 0
    bh = bl.height if "bottom" in edges else 0
    out = Image.new("RGBA", (w, h))

    def put(part, x, y, pw, ph):
        if pw > 0 and ph > 0:
            out.alpha_composite(element(svg, n(part)).resize((pw, ph), Image.LANCZOS), (x, y))

    cw, ch = w - lw - rw, h - th - bh
    put("center", lw, th, cw, ch)
    if th:
        put("top", lw, 0, cw, th)
    if bh:
        put("bottom", lw, h - bh, cw, bh)
    if lw:
        put("left", 0, th, lw, ch)
    if rw:
        put("right", w - rw, th, rw, ch)
    if th and lw:
        put("topleft", 0, 0, lw, th)
    if th and rw:
        put("topright", w - rw, 0, rw, th)
    if bh and lw:
        put("bottomleft", 0, h - bh, lw, bh)
    if bh and rw:
        put("bottomright", w - rw, h - bh, rw, bh)
    return out


def shadow_box(canvas, x, y, w, h, radius=18, alpha=110):
    sh = Image.new("RGBA", canvas.size)
    ImageDraw.Draw(sh).rounded_rectangle((x, y + 6, x + w, y + h + 6), 10, fill=(0, 0, 0, alpha))
    canvas.alpha_composite(sh.filter(ImageFilter.GaussianBlur(radius)))


def glass_backdrop(canvas, box, radius=16):
    """Imitate KWin blur + contrast behind a glass surface."""
    if not BLUR:
        return
    region = canvas.crop(box).filter(ImageFilter.GaussianBlur(radius))
    region = ImageEnhance.Color(region).enhance(1.4)
    canvas.paste(region, box[:2])


def window(canvas, x, y, w, h, title, active, app):
    pad = 14
    deco = os.path.join(AUR, "decoration.svg")
    prefix = "decoration" if active else "decoration-inactive"
    glass_backdrop(canvas, (x - 6, y - 2, x + w + 6, y + h + 6), 14)   # blur behind the whole glass frame
    fr = frame(deco, prefix, w + 2 * pad, h + 2 * pad)
    canvas.alpha_composite(fr, (x - pad, y - pad))
    # client area
    cx, cy, cw, chh = x + 5, y + 28, w - 10, h - 33
    d = ImageDraw.Draw(canvas)
    app(canvas, d, cx, cy, cw, chh)
    # title
    canvas.alpha_composite(icon("folder", 18), (x + 10, y + 5))
    # dark text with a white halo, as the Aurorae theme draws it on clear glass
    tc = (14, 22, 32) if active else (64, 78, 94)
    halo = Image.new("RGBA", canvas.size)
    ImageDraw.Draw(halo).text((x + 34, y + 13), title, font=font(13, True), fill=(255, 255, 255, 235 if active else 160),
                              anchor="lm", stroke_width=2, stroke_fill=(255, 255, 255, 150 if active else 90))
    canvas.alpha_composite(halo.filter(ImageFilter.GaussianBlur(1.2)))
    d.text((x + 34, y + 13), title, font=font(13, True), fill=tc, anchor="lm")
    bx = x + w - 6
    for name, bw in (("close", 44), ("maximize", 28), ("minimize", 28)):
        bx -= bw
        st = "active" if active else "inactive"
        canvas.alpha_composite(element(os.path.join(AUR, name + ".svg"), f"{st}-center"), (bx, y + 4))
        bx -= 2


def dolphin(canvas, d, x, y, w, h):
    d.rectangle((x, y, x + w, y + h), fill=(240, 245, 251))
    d.rectangle((x, y, x + w, y + 34), fill=(226, 236, 248))
    for i, t in enumerate(("Back", "Forward", "Home")):
        d.rounded_rectangle((x + 8 + i * 70, y + 6, x + 70 + i * 70, y + 28), 4, fill=(233, 240, 249), outline=(200, 214, 232))
        d.text((x + 39 + i * 70, y + 17), t, font=font(12), fill=(16, 28, 44), anchor="mm")
    d.rectangle((x, y + 34, x + 170, y + h), fill=(234, 241, 250))
    places = [("user-home", "Home"), ("user-desktop", "Desktop"), ("folder-documents", "Documents"),
              ("folder-download", "Downloads"), ("folder-pictures", "Pictures"), ("user-trash", "Trash")]
    for i, (ic, t) in enumerate(places):
        yy = y + 50 + i * 30
        if i == 2:
            d.rounded_rectangle((x + 6, yy - 4, x + 164, yy + 22), 4, fill=(40, 120, 214))
        canvas.alpha_composite(icon(ic, 20), (x + 12, yy - 1))
        d.text((x + 40, yy + 9), t, font=font(13), fill=(255, 255, 255) if i == 2 else (16, 28, 44), anchor="lm")
    d.rectangle((x + 170, y + 34, x + w, y + h), fill=(252, 253, 255))
    files = [("folder", "Projects"), ("folder-music", "Music"), ("folder-videos", "Videos"),
             ("folder-pictures", "Holiday"), ("folder", "Reports"), ("folder-documents", "Letters")]
    for i, (ic, t) in enumerate(files):
        gx, gy = x + 200 + (i % 4) * 120, y + 60 + (i // 4) * 110
        canvas.alpha_composite(icon(ic, 64), (gx + 18, gy))
        d.text((gx + 50, gy + 80), t, font=font(13), fill=(16, 28, 44), anchor="mm")


def writer(canvas, d, x, y, w, h):
    d.rectangle((x, y, x + w, y + h), fill=(232, 238, 246))
    d.rectangle((x + 60, y + 30, x + w - 60, y + h), fill=(255, 255, 255))
    for i in range(9):
        d.line((x + 100, y + 70 + i * 22, x + w - 100 - (i % 3) * 60, y + 70 + i * 22), fill=(180, 188, 200), width=3)


def panel(canvas):
    ph = 44
    y = H - ph
    glass_backdrop(canvas, (0, y, W, H), 18)
    svg = os.path.join(PLASMA, "translucent" if BLUR else "", "widgets", "panel-background.svg")
    canvas.alpha_composite(frame(svg, "", W, ph, edges=("top",)), (0, y))
    d = ImageDraw.Draw(canvas)
    # launcher: orb + "Start"
    canvas.alpha_composite(icon("start-here", 32), (8, y + 6))
    d.text((44, y + ph // 2), "Start", font=font(14, True), fill=(236, 245, 255), anchor="lm")
    tasks = os.path.join(PLASMA, "widgets", "tasks.svg")
    items = [("focus", "folder", "Documents — Dolphin"), ("normal", "folder-documents", "Report.odt — Writer"),
             ("hover", "computer", "System Monitor")]
    x = 100
    for state, ic, label in items:
        tw = 210
        canvas.alpha_composite(frame(tasks, state, tw, ph - 6), (x, y + 3))
        canvas.alpha_composite(icon(ic, 24, "devices" if ic == "computer" else "places"), (x + 10, y + 10))
        d.text((x + 42, y + ph // 2), label, font=font(13), fill=(236, 245, 255), anchor="lm")
        x += tw + 4
    # tray + clock
    for i, glyph in enumerate(("◐", "♪", "⇅")):
        d.text((W - 190 + i * 30, y + ph // 2), glyph, font=font(16), fill=(200, 220, 240), anchor="mm")
    d.text((W - 60, y + 14), "14:32", font=font(14, True), fill=(236, 245, 255), anchor="mm")
    d.text((W - 60, y + 31), "16/11/2026", font=font(11), fill=(176, 196, 220), anchor="mm")


def notification(canvas):
    w, h = 360, 96
    x, y = W - w - 16, H - 44 - h - 16
    sh = Image.new("RGBA", canvas.size)
    ImageDraw.Draw(sh).rounded_rectangle((x, y + 4, x + w, y + h + 4), 8, fill=(0, 0, 0, 120))
    canvas.alpha_composite(sh.filter(ImageFilter.GaussianBlur(12)))
    glass_backdrop(canvas, (x, y, x + w, y + h), 16)
    svg = os.path.join(PLASMA, "translucent" if BLUR else "", "dialogs", "background.svg")
    canvas.alpha_composite(frame(svg, "", w, h), (x, y))
    canvas.alpha_composite(icon("start-here", 40), (x + 16, y + 26))
    d = ImageDraw.Draw(canvas)
    d.text((x + 70, y + 30), "Welcome to FortizanOS", font=font(14, True), fill=(236, 245, 255), anchor="lm")
    d.text((x + 70, y + 54), "Updates are ready to install.", font=font(13), fill=(176, 196, 220), anchor="lm")
    d.text((x + 70, y + 74), "Open Discover", font=font(13), fill=(104, 178, 238), anchor="lm")


def main():
    wp = os.path.join(ROOT, "build", "wallpaper-src", "1920x1080.png")
    canvas = Image.open(wp).convert("RGBA").resize((W, H), Image.LANCZOS)
    shadow_box(canvas, 760, 90, 640, 440, alpha=90)
    window(canvas, 760, 90, 640, 440, "Report.odt — LibreOffice Writer", False, writer)
    shadow_box(canvas, 150, 170, 820, 520, alpha=130)
    window(canvas, 150, 170, 820, 520, "Documents — Dolphin", True, dolphin)
    panel(canvas)
    notification(canvas)
    d = ImageDraw.Draw(canvas)
    d.text((16, 16), "MOCK-UP rendered from the theme files — not a screenshot" + ("" if BLUR else " (effects OFF)"),
           font=font(12), fill=(255, 255, 255, 160))
    os.makedirs(os.path.dirname(OUT), exist_ok=True)
    canvas.convert("RGB").save(OUT, quality=92)
    print(OUT)


if __name__ == "__main__":
    main()
