"""FortizanOS "Aero" palette — the single source of truth for every colour.

Inspired by the experimental glass direction of Longhorn build 4074:
deep blue glass, cyan light, cool highlights. Original values, not copied
from any Microsoft asset.

Change a value here, run `python3 tools/gen-theme.py`, rebuild.
"""

# Core hues (R, G, B)
NAVY_DEEP = (7, 20, 40)        # darkest glass / wallpaper base
NAVY = (13, 36, 68)            # taskbar body
NAVY_SOFT = (24, 56, 98)       # pop-up / notification body
AERO_BLUE = (32, 98, 172)      # active title bar body
SKY = (104, 178, 238)          # glass sheen / hover
CYAN = (58, 200, 240)          # luminous accent (focus, active highlight)
ICE = (226, 238, 250)          # light frosted surfaces
SLATE = (92, 108, 128)         # inactive / muted
AMBER = (240, 170, 60)         # "needs attention" (task bar)
CLOSE_RED = (200, 52, 44)      # close button glass

# Text
TEXT_ON_GLASS = (236, 245, 255)   # on dark glass (panel, title bars, pop-ups)
TEXT_MUTED_ON_GLASS = (176, 196, 220)
TEXT_ON_LIGHT = (16, 28, 44)      # on light app surfaces
TEXT_MUTED_ON_LIGHT = (92, 106, 124)

# App surfaces (solid — readability first)
WINDOW_BG = (240, 245, 251)
VIEW_BG = (252, 253, 255)
HEADER_BG = (226, 236, 248)
BUTTON_BG = (233, 240, 249)
SELECTION = (40, 120, 214)

# --- Longhorn 4074 "Aero" transparent glass (v0.2.1 redesign) ---------------
# 4074's Aero is defined by *fully transparent* window borders (unlike the
# greenish "Jade" placeholder) and a transparent taskbar/sidebar. So window
# frames are pale, mostly clear glass; the taskbar is smoked clear glass.
# KWin's blur provides the frosting; the tints stay light so the glass reads
# as transparent, not as a coloured panel.
GLASS_CLEAR = (234, 245, 252)    # window frame glass (pale, slightly cyan)
GLASS_ICE = (196, 226, 246)      # lower part of the frame glass
GLASS_EDGE = (28, 44, 62)        # thin dark outline around glass frames
SMOKE = (6, 14, 26)              # taskbar / shell smoked glass
SMOKE_LIGHT = (34, 54, 80)
TITLE_TEXT = (14, 22, 32)        # dark title text on clear glass
TITLE_TEXT_INACTIVE = (64, 78, 94)
TITLE_GLOW = (255, 255, 255)     # white halo behind title text (readability)

# Glass opacity levels (0..1). Opaque variants are used automatically when
# blur is switched off ("performance mode").
ALPHA_TASKBAR = 0.48
ALPHA_POPUP = 0.66
ALPHA_TOOLTIP = 0.80
ALPHA_WIDGET = 0.45
ALPHA_TITLE_ACTIVE = 0.34
ALPHA_TITLE_INACTIVE = 0.20
MENU_OPACITY_PERCENT = 90   # Breeze context menus ("lightly frosted")

# KWin blur (Plasma 6: strength 1-15, noise 0-14). Stronger than v0.2.0
# because the glass itself is now mostly clear.
BLUR_STRENGTH = 10
BLUR_NOISE = 3


def hexc(c):
    return "#%02x%02x%02x" % c


def mix(a, b, t):
    """Linear mix of two RGB colours, t=0 -> a, t=1 -> b."""
    return tuple(round(a[i] + (b[i] - a[i]) * t) for i in range(3))


def kde(c):
    """KDE colour-scheme notation 'r,g,b'."""
    return "%d,%d,%d" % c
