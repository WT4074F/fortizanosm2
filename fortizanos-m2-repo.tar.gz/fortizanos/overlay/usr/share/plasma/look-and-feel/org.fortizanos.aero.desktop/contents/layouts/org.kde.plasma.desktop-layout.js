// FortizanOS default desktop layout (Plasma scripting API).
// Runs once, the first time a user logs in with the Fortizan Aero global theme.
// Longhorn-style taskbar: full-width, bottom, task buttons with labels.

var desktops = desktopsForActivity(currentActivity());
for (var i = 0; i < desktops.length; i++) {
    var desk = desktops[i];
    desk.wallpaperPlugin = "org.kde.image";
    desk.currentConfigGroup = ["Wallpaper", "org.kde.image", "General"];
    desk.writeConfig("Image", "file:///usr/share/wallpapers/FortizanAero/");
}

var panel = new Panel;
panel.location = "bottom";
panel.height = 2 * Math.floor(gridUnit * 2.5 / 2);
panel.floating = false;              // edge-to-edge taskbar, no floating gap
panel.hiding = "none";

var launcher = panel.addWidget("org.kde.plasma.kickoff");   // stock launcher, themed (custom Start menu = Milestone 3)
launcher.currentConfigGroup = ["General"];
launcher.writeConfig("icon", "fortizanos-logo");
launcher.writeConfig("menuLabel", "Start");                 // orb + label, Longhorn-style start button

var tasks = panel.addWidget("org.kde.plasma.taskmanager");  // buttons WITH labels, like Longhorn
tasks.currentConfigGroup = ["General"];
tasks.writeConfig("launchers", ["preferred://filemanager", "preferred://browser"]);
tasks.writeConfig("groupingStrategy", 0);                   // one button per window
tasks.writeConfig("maxStripes", 1);

panel.addWidget("org.kde.plasma.marginsseparator");
panel.addWidget("org.kde.plasma.systemtray");

var clock = panel.addWidget("org.kde.plasma.digitalclock");
clock.currentConfigGroup = ["Appearance"];
clock.writeConfig("showDate", true);
clock.writeConfig("dateDisplayFormat", "BelowTime");

panel.addWidget("org.kde.plasma.showdesktop");              // corner "show desktop" strip
