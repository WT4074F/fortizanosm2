# FortizanOS — Project status

_Last updated: 2026-11-16_

| Milestone | Scope | State |
|---|---|---|
| **M1** Foundation | Fedora 45 KDE base, reproducible ISO build, Btrfs, Flatpak, package config | Build works; testing **partly done** |
| **M2** Desktop identity | Fortizan Aero glass theme, Longhorn-style taskbar, lighter app set, effects switch, measurements | **Implemented — awaiting first build and VM test** |
| M3 | Start menu, Run dialog, Explorer replacement, Wine, sidebar | Not started (by instruction) |

## Milestone 1 — what is proven

- ✅ ISO **0.1.0** built on GitHub Actions from a clean repository
  (installation, configuration scripts, compression, ISO all completed).
- ✅ Boots in VirtualBox (BIOS path observed); kernel, guest drivers, networking start.
- ✅ Correct VirtualBox settings identified (64-bit type, VMSVGA 128 MB, Hyper-V off).

## Milestone 1 — still open

- ⏳ Desktop shown on screen in VirtualBox (black screen; next step: **3D acceleration on**, see TESTING.md).
- ⏳ `verify-system.sh` run in the live session.
- ⏳ Installation to the virtual disk + reboot (Btrfs check).
- ⏳ Second consecutive clean build (the M2 build counts if it succeeds unchanged).
- ⏳ UEFI boot test.

## Milestone 2 — delivered in the repository

- Fortizan Aero visual identity, all generated from `tools/palette.py`:
  Plasma style (translucent + opaque), Aurorae glass title bars with blur
  mask and glossy buttons, colour scheme, original wallpaper, glossy icons,
  global theme with Longhorn-style taskbar layout.
- System defaults in `/etc/xdg` (with backups of replaced files).
- `fortizan-effects` on/off switch + menu entry (no background process).
- **v0.2.0 → redesign (owner feedback):** Longhorn 4074-style *transparent*
  glass (clear pale borders, smoked taskbar, orb + "Start" button, no Windows logo).
- **Single theme:** all other themes removed and kept out on updates
  (required KDE fallbacks retained — see DECISIONS D-014).
- **UK keyboard** default (installer, console, desktop).
- **Flat transparent title bars** and flat caption buttons.
- **Default font Selawik** (open-source Segoe UI replacement), downloaded at build time from Microsoft's release and checksum-verified.
- Lighter package set: Akonadi + MariaDB, PIM apps, KDE Connect, duplicates
  and niche apps removed; LibreOffice Writer/Calc/Impress kept.
- Tooling: theme generator, theme checker, mock-up renderer, dependency
  resolution in preflight, performance measurement script, M2 tests (T5).
- Docs: `docs/M2-PLAN.md`, `docs/M2-DESKTOP.md`, `docs/PACKAGES.md`,
  `docs/PERFORMANCE.md`, updated `docs/DECISIONS.md` and `docs/TESTING.md`.

## Milestone 2 — not yet verified

- ⏳ Build of **0.2.0** (dependency preflight will confirm the trimmed set first).
- ⏳ Desktop appearance and behaviour in VirtualBox (TEST-PLAN T5).
- ⏳ Performance figures for 0.1.0 vs 0.2.0 (`docs/PERFORMANCE.md` table is empty
  until measured — no numbers are assumed).

## Known issues / decisions pending

- The build now needs to reach github.com once (Selawik download); a failed download stops the build with a clear message.

- Fedora logos remain in installer/boot menu — **must be replaced before any public ISO**.
- Login screen and boot splash not themed (candidate for M3 or an M2.1).
- Language is English (US) and time zone UTC — owner may want en_GB / Europe/London.
- Repository access for Claude: GitHub app not connected; changes are delivered
  as an archive that the build workflow unpacks (see docs/BUILD.md).
