# FortizanOS — Longhorn Aero Linux

A Fedora KDE Plasma–based Linux distribution.

**Status: Milestone 2 — desktop identity.** Fedora 45 KDE Plasma 6.8 wearing
**Fortizan Aero**: an original frosted-glass look inspired by the experimental
Longhorn build 4074 Aero direction, a Longhorn-style taskbar, a lighter app set
and a one-click effects switch. Built reproducibly into a bootable live/install
ISO with Btrfs installs and Flatpak/Flathub. See [PROJECT_STATUS.md](PROJECT_STATUS.md).

![Fortizan Aero mock-up](docs/images/m2-mockup.png)

## Quick start

On a **Fedora 45** machine (or any Linux host with podman/docker):

```bash
make check-theme      # validate the theme files (seconds)
make inspect          # check this machine can build (read-only)
make setup            # Fedora host only: install lorax/livemedia-creator etc.
make preflight        # 1-minute check that every package in the kickstart exists
sudo make iso         # Fedora 45 host build      ─┐ pick one
make iso-container    # any Linux host, via podman ─┘
make verify           # static ISO checks
make vbox-test        # boot it in VirtualBox (UEFI)
```

The ISO lands in `out/<build-id>/` with its sha256, the exact flattened
kickstart used, and `build-info.txt`. No-local-Fedora option: run the
**Build ISO** GitHub Actions workflow and download the artifact.

## Repository layout

| Path | Purpose |
|---|---|
| `build.conf` | All build parameters (Fedora release, names, ISO label) |
| `kickstarts/fortizanos-live-kde.ks` | Top-level image definition |
| `kickstarts/include/` | repos · live base · KDE package set · FortizanOS config |
| `overlay/` | Files copied verbatim into the image (embedded into the kickstart at build time) |
| `tools/` | Theme generator (`gen-theme.py` + `palette.py`), checker, mock-up renderer |
| `scripts/` | inspect · setup · preflight · build · container build · verify · VirtualBox |
| `tests/` | `verify-system.sh` (run inside the VM) and the M1 test plan |
| `docs/` | Build guide, testing guide, design decisions, environment report |
| `.github/workflows/` | CI: shellcheck, preflight, full ISO build |

## Documentation

- [docs/M2-DESKTOP.md](docs/M2-DESKTOP.md) — the Fortizan Aero desktop explained (start here)
- [docs/PACKAGES.md](docs/PACKAGES.md) · [docs/PERFORMANCE.md](docs/PERFORMANCE.md) · [docs/M2-PLAN.md](docs/M2-PLAN.md)
- [docs/BUILD.md](docs/BUILD.md) — build instructions and troubleshooting
- [docs/TESTING.md](docs/TESTING.md) + [tests/TEST-PLAN.md](tests/TEST-PLAN.md) — Milestone 1 acceptance testing
- [docs/DECISIONS.md](docs/DECISIONS.md) — why things are the way they are
- [docs/ENVIRONMENT.md](docs/ENVIRONMENT.md) — build-environment requirements and inspection results
